DROP EXTENSION IF EXISTS pgcrypto;
CREATE EXTENSION pgcrypto;

DROP TABLE IF EXISTS user_event;
DROP TABLE IF EXISTS date_event;
DROP TABLE IF EXISTS user_date;
DROP TABLE IF EXISTS blocked_users;

DROP TABLE IF EXISTS dates;
DROP TABLE IF EXISTS events;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
    uid INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    username VARCHAR NOT NULL UNIQUE,
    pwd VARCHAR NOT NULL,
    available BOOLEAN NOT NULL
);

CREATE TABLE events (
    eid INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tmid VARCHAR NOT NULL
);

CREATE TABLE dates (
    did INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    date_name VARCHAR NOT NULL,
    proposer INT REFERENCES users(uid),
    final_event INT REFERENCES events(eid)
);

CREATE TABLE user_date (
    uid INT REFERENCES users(uid),
    did INT REFERENCES dates(did),
    -- 0 ongoing, 1 accepted, 2 rejected
    status SMALLINT,

    PRIMARY KEY (uid, did)
);

CREATE TABLE user_event (
    uid INT REFERENCES users(uid),
    eid INT REFERENCES events(eid),
    -- -1 not set
    preference SMALLINT,
    -- -1 not set, 0 unavailable, 1 available
    available SMALLINT,

    PRIMARY KEY (uid, eid)
);

CREATE TABLE date_event (
    did INT REFERENCES dates(did),
    eid INT REFERENCES events(eid),

    PRIMARY KEY (did, eid)
);

CREATE TABLE blocked_users (
    uid INT REFERENCES users(uid),
    blocked_uid INT REFERENCES users(uid),

    PRIMARY KEY (uid, blocked_uid)
);

CREATE OR REPLACE FUNCTION signup(username VARCHAR, password VARCHAR)
    RETURNS VARCHAR
    LANGUAGE plpgsql
AS
$$
DECLARE
    existing INT;
    lower_name VARCHAR := LOWER(username);
BEGIN
    SELECT (uid) INTO existing FROM users WHERE users.username=lower_name;
    IF existing IS NOT NULL
    THEN
        RETURN 'username exists';
    END IF;
    INSERT INTO users(username, pwd, available) VALUES (lower_name, crypt(password, gen_salt('bf', 8)), TRUE);
    RETURN 'success';
END
$$;

CREATE OR REPLACE FUNCTION login(username VARCHAR, password VARCHAR)
    RETURNS BOOLEAN
    LANGUAGE plpgsql
AS
$$
DECLARE
    match INT;
    lower_name VARCHAR = LOWER(username);
BEGIN
    SELECT (uid) INTO match FROM users WHERE users.username = lower_name AND pwd = crypt(password, pwd);
    IF match IS NOT NULL
    THEN
        RETURN TRUE;
    ELSE
        RETURN FALSE;
    END IF;
END
$$;

CREATE OR REPLACE FUNCTION createDate(date_name VARCHAR, proposer_username VARCHAR, events VARCHAR[], invitees VARCHAR[], OUT date_id INT, OUT msg VARCHAR)
    LANGUAGE plpgsql
AS
$$
DECLARE
user_id INT;
event_id INT;
event_tmid VARCHAR;
invited_username VARCHAR;
BEGIN
    INSERT INTO dates(date_name, proposer, final_event)
    SELECT createDate.date_name, uid, NULL FROM users WHERE username = proposer_username
	RETURNING did INTO date_id;

    FOREACH invited_username IN ARRAY invitees LOOP
        SELECT uid INTO user_id FROM users WHERE username = invited_username;
		IF date_id IS NULL
		THEN
			SELECT proposer_username || ' does not exist' INTO msg;
			RETURN;
        ELSIF user_id IS NULL
        THEN
            SELECT invited_username || ' does not exist' INTO msg;
			RETURN;
        ELSE
            INSERT INTO user_date(uid, did, status)
            VALUES (user_id, date_id, 0);
        END IF;
    END LOOP;

    FOREACH event_tmid IN ARRAY events LOOP
        INSERT INTO events(tmid)
        VALUES (event_tmid)
        RETURNING eid INTO event_id;

        INSERT INTO date_event(did, eid)
        VALUES (date_id, event_id);

        INSERT INTO user_event(uid, eid, preference, available)
        SELECT uid, event_id, -1, -1
        FROM user_date WHERE did = date_id;
    END LOOP;
    SELECT 'success' INTO msg;
	RETURN;
END;
$$;
