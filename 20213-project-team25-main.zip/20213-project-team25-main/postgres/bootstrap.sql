SELECT signup('username', 'password');
SELECT signup('username2', 'password');
SELECT signup('invitee1', 'password');
SELECT signup('invitee2', 'password');
SELECT signup('invitee3', 'password');
SELECT signup('block1', 'password');
SELECT signup('block2', 'password');
