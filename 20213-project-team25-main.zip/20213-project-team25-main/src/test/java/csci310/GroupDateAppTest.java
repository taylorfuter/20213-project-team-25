package csci310;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import io.lettuce.core.RedisClient;
import io.lettuce.core.api.StatefulRedisConnection;

public class GroupDateAppTest {

    @Mock
    RedisClient client;

    @Mock
    StatefulRedisConnection<String, String> redis;

    AutoCloseable closeable;

    @Before
    public void setup() {
        closeable = MockitoAnnotations.openMocks(this);
    }

    @After
    public void cleanup() throws Exception {
        closeable.close();
    }

    @Test
    public void testMain() throws Exception {
        Connection connetion = mock(Connection.class);

        String[] args = new String[0];

        try (MockedStatic<DriverManager> mockedDriver = mockStatic(DriverManager.class)) {
            try (MockedStatic<RedisClient> mockedClient = mockStatic(RedisClient.class)) {
                mockedDriver.when(() -> DriverManager.getConnection(any(), any(), any())).thenReturn(connetion);
                mockedClient.when(() -> RedisClient.create(anyString())).thenReturn(client);
                doReturn(redis).when(client).connect();

                GroupDateApp.main(args);
                assertEquals(connetion, GroupDateApp.conn);
                assertEquals(redis, GroupDateApp.redis);
                assertTrue("Application not initialized", GroupDateApp.context.isActive());
                GroupDateApp.context.close();
            }
        }
    }

    @Test
    public void testGetPassword() throws IOException, UnsupportedEncodingException {
        File testFile = new File("./.dbpwd");
        String orig = Files.readString(Path.of(".dbpwd"));

        Files.delete(Path.of(".dbpwd"));
        assertThrows(Exception.class, () -> {
            GroupDateApp.getPassword();
        });

        String data = "";
        FileUtils.writeStringToFile(testFile, data, "UTF-8");

        assertThrows(Exception.class, () -> {
            GroupDateApp.getPassword();
        });

        data = "POSTGRES_PASSWORD=";
        FileUtils.writeStringToFile(testFile, data, "UTF-8");

        try {
            String pwd = GroupDateApp.getPassword();
            assertEquals("", pwd);
        } catch (Exception e) {
            fail("Unexpected getPassword throw");
        }

        data = "POSTGRES_PASSWORD=testpassword1";
        FileUtils.writeStringToFile(testFile, data, "UTF-8");

        try {
            String pwd = GroupDateApp.getPassword();
            assertEquals("testpassword1", pwd);
        } catch (Exception e) {
            fail("Unexpected getPassword throw");
        }

        Files.writeString(Path.of(".dbpwd"), orig);
    }

}
