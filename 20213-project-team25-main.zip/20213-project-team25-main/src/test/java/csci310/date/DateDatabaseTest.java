package csci310.date;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import csci310.exception.DateCreationException;
import csci310.exception.NoNameSpecifiedException;
import csci310.exception.SelfInvitedException;
import csci310.exception.UnauthorizedException;
import csci310.model.Date;
import csci310.model.Event;

public class DateDatabaseTest {

    @Mock
    Connection conn;

    @Mock
    PreparedStatement pst;

    @Mock
    ResultSet result;

    @Captor
    ArgumentCaptor<String> stringCaptor;

    AutoCloseable closeable;

    @Before
    public void setup() {
        closeable = MockitoAnnotations.openMocks(this);
    }

    @After
    public void cleanup() throws Exception {
        closeable.close();
    }

    @Test
    public void testCreateDateNoEvent() throws Exception {
        doReturn(pst).when(conn).prepareStatement(any());
        String[] invitees = new String[] { "a", "b" };
        DateDatabase uut = new DateDatabase();

        String[] events = new String[] {};
        try {
            uut.createDate(conn, "testname", "testproposer", events, invitees);
            fail("Expected throw");
        } catch (DateCreationException e) {
            assertEquals("No events specified", e.getMessage());
        } catch (Exception e) {
            fail("Unexpected exception type");
        }
    }

    @Test
    public void testCreateDateNoInvitee() throws Exception {
        doReturn(pst).when(conn).prepareStatement(any());
        String[] invitees = new String[] {};
        DateDatabase uut = new DateDatabase();

        String[] events = new String[] { "name 1" };

        try {
            uut.createDate(conn, "testname", "testproposer", events, invitees);
            fail("Expected throw");
        } catch (DateCreationException e) {
            assertEquals("No one invited", e.getMessage());
        } catch (Exception e) {
            fail("Unexpected exception type");
        }
    }

    @Test
    public void testCreateDateUnknown() throws Exception {
        String[] invitees = new String[] { "a", "b" };
        DateDatabase uut = new DateDatabase();

        String[] events = new String[] { "name 1" };

        doReturn(pst).when(conn).prepareStatement(any());
        doReturn(result).when(pst).executeQuery();
        doReturn(false).when(result).next();

        try {
            uut.createDate(conn, "testname", "testproposer", events, invitees);
            fail("Expected throw");
        } catch (DateCreationException e) {
            assertEquals("unknown error", e.getMessage());
        } catch (Exception e) {
            fail("Unexpected exception type");
        }
    }

    @Test
    public void testCreateDateNoUser() throws Exception {
        String[] invitees = new String[] { "a", "b" };
        DateDatabase uut = new DateDatabase();

        String[] events = new String[] { "name 1" };

        doReturn(pst).when(conn).prepareStatement(any());
        doReturn(result).when(pst).executeQuery();
        doReturn(true).when(result).next();
        doReturn("this").when(result).getString("msg");
        doReturn(12).when(result).getInt("date_id");

        try {
            uut.createDate(conn, "testname", "testproposer", events, invitees);
            fail("Expected throw");
        } catch (DateCreationException e) {
            assertEquals("this", e.getMessage());
        } catch (Exception e) {
            fail("Unexpected exception type");
        }
    }

    @Test
    public void testCreateDateSelfInvite() throws Exception {
        String[] invitees = new String[] { "testproposer", "b" };
        DateDatabase uut = new DateDatabase();

        String[] events = new String[] { "name 1", "name 2" };

        doReturn(pst).when(conn).prepareStatement(any());
        doReturn(result).when(pst).executeQuery();
        doReturn(true).when(result).next();
        doReturn("success").when(result).getString("msg");
        doReturn(12).when(result).getInt("date_id");

        assertThrows(SelfInvitedException.class,
                () -> uut.createDate(conn, "testname", "testproposer", events, invitees));
    }

    @Test
    public void testCreateDateNoName() throws Exception {
        String[] invitees = new String[] { "a", "b" };
        DateDatabase uut = new DateDatabase();

        String[] events = new String[] { "name 1", "name 2" };

        doReturn(pst).when(conn).prepareStatement(any());
        doReturn(result).when(pst).executeQuery();
        doReturn(true).when(result).next();
        doReturn("success").when(result).getString("msg");
        doReturn(12).when(result).getInt("date_id");

        assertThrows(NoNameSpecifiedException.class,
                () -> uut.createDate(conn, null, "testproposer", events, invitees));
    }

    @Test
    public void testCreateDateSuccess() throws Exception {
        String[] invitees = new String[] { "a", "b" };
        DateDatabase uut = new DateDatabase();

        String[] events = new String[] { "name 1", "name 2" };

        doReturn(pst).when(conn).prepareStatement(any());
        doReturn(result).when(pst).executeQuery();
        doReturn(true).when(result).next();
        doReturn("success").when(result).getString("msg");
        doReturn(12).when(result).getInt("date_id");

        assertEquals(12, uut.createDate(conn, "testname", "testproposer", events, invitees));
    }

    @Test
    public void testGetDate() throws Exception {
        doReturn(pst).when(conn).prepareStatement(any());
        doReturn(result).when(pst).executeQuery();
        doReturn(true).when(result).next();
        doReturn(1).when(result).getInt("did");
        doReturn("proposer").when(result).getString("proposer");
        doReturn("name").when(result).getString("date_name");
        doReturn(0).when(result).getInt("status");
        DateDatabase uut = mock(DateDatabase.class);
        doReturn(1).when(uut).getUserOfDate(any(), anyInt(), any());
        doReturn(new ArrayList<Event>()).when(uut).getEventsOfDate(any(), anyInt(), anyInt());
        doReturn(new ArrayList<String>()).when(uut).getInviteesOfDate(any(), anyInt());
        when(uut.getDate(any(), anyInt(), any())).thenCallRealMethod();

        Date testResult = uut.getDate(conn, 1, "this");

        assertEquals(1, testResult.getId());
        assertEquals("proposer", testResult.getProposer());
        assertEquals("name", testResult.getName());
        assertEquals("ongoing", testResult.getStatus());
        assertEquals(new ArrayList<Event>(), testResult.getEvents());
        assertEquals(new ArrayList<String>(), testResult.getInvitees());

        doReturn(1).when(result).getInt("status");
        testResult = uut.getDate(conn, 1, "this");
        assertEquals("accepted", testResult.getStatus());

        doReturn(2).when(result).getInt("status");
        testResult = uut.getDate(conn, 1, "this");
        assertEquals("rejected", testResult.getStatus());

        doReturn(3).when(result).getInt("status");
        testResult = uut.getDate(conn, 1, "this");
        assertEquals("", testResult.getStatus());
    }

    @Test
    public void testGetEventsOfDate() throws Exception {
        doReturn(pst).when(conn).prepareStatement(any());
        doReturn(result).when(pst).executeQuery();

        doAnswer(new Answer<Boolean>() {
            private int count = 0;

            public Boolean answer(InvocationOnMock invocation) {
                if (count++ == 1)
                    return false;
                return true;
            }
        }).when(result).next();

        doReturn("tmid").when(result).getString("tmid");
        doReturn(-1).when(result).getInt("available");
        doReturn(-1).when(result).getInt("preference");

        DateDatabase uut = new DateDatabase();

        List<Event> resultEvents = uut.getEventsOfDate(conn, 1, 1);
        assertEquals(1, resultEvents.size());
        assertEquals("tmid", resultEvents.get(0).getTmid());
        assertEquals(Integer.valueOf(-1), resultEvents.get(0).getAvailable());
        assertEquals(Integer.valueOf(-1), resultEvents.get(0).getAvailable());
    }

    @Test
    public void testGetInviteesOfDate() throws Exception {
        doReturn(pst).when(conn).prepareStatement(any());
        doReturn(result).when(pst).executeQuery();

        doAnswer(new Answer<Boolean>() {
            private int count = 0;

            public Boolean answer(InvocationOnMock invocation) {
                if (count++ == 1)
                    return false;
                return true;
            }
        }).when(result).next();

        doReturn("test").when(result).getString("username");

        DateDatabase uut = new DateDatabase();

        List<String> resultInvitees = uut.getInviteesOfDate(conn, 1);

        assertEquals(1, resultInvitees.size());
        assertEquals("test", resultInvitees.get(0));
    }

    @Test
    public void testGetUserOfDate() throws Exception {
        doReturn(pst).when(conn).prepareStatement(any());
        doReturn(result).when(pst).executeQuery();
        doReturn(true).when(result).next();
        doReturn(12).when(result).getInt("uid");

        DateDatabase uut = new DateDatabase();

        int resultId = uut.getUserOfDate(conn, 1, "h");

        assertEquals(12, resultId);

        doReturn(false).when(result).next();
        assertThrows(UnauthorizedException.class, () -> uut.getUserOfDate(conn, 1, "h"));
    }

    @Test
    public void testGetProposed() throws Exception {
        DateDatabase uut = mock(DateDatabase.class);
        Date testDate = new Date(1, "proposer", "name", new ArrayList<Event>(), "status",
                new ArrayList<String>());

        doReturn(testDate).when(uut).getDate(any(), anyInt(), any());
        when(uut.getProposed(any(), any())).thenCallRealMethod();

        doReturn(pst).when(conn).prepareStatement(any());
        doReturn(result).when(pst).executeQuery();
        doAnswer(new Answer<Boolean>() {
            private int count = 0;

            public Boolean answer(InvocationOnMock invocation) {
                if (count++ == 1)
                    return false;
                return true;
            }
        }).when(result).next();

        List<Date> testResult = uut.getProposed(conn, "h");
        assertEquals(1, testResult.size());
        assertEquals("proposer", testResult.get(0).getProposer());
        assertEquals("name", testResult.get(0).getName());
        assertEquals(new ArrayList<Event>(), testResult.get(0).getEvents());
        assertEquals("status", testResult.get(0).getStatus());
        assertEquals(new ArrayList<String>(), testResult.get(0).getInvitees());
    }

    @Test
    public void testGetInvited() throws Exception {
        DateDatabase uut = mock(DateDatabase.class);
        Date testDate = new Date(1, "proposer", "name", new ArrayList<Event>(), "status",
                new ArrayList<String>());

        doReturn(testDate).when(uut).getDate(any(), anyInt(), any());
        when(uut.getInvited(any(), any())).thenCallRealMethod();

        doReturn(pst).when(conn).prepareStatement(any());
        doReturn(result).when(pst).executeQuery();
        doAnswer(new Answer<Boolean>() {
            private int count = 0;

            public Boolean answer(InvocationOnMock invocation) {
                if (count++ == 1)
                    return false;
                return true;
            }
        }).when(result).next();

        List<Date> testResult = uut.getInvited(conn, "h");
        assertEquals(1, testResult.size());
        assertEquals("proposer", testResult.get(0).getProposer());
        assertEquals("name", testResult.get(0).getName());
        assertEquals(new ArrayList<Event>(), testResult.get(0).getEvents());
        assertEquals("status", testResult.get(0).getStatus());
        assertEquals(new ArrayList<String>(), testResult.get(0).getInvitees());
    }

    @Test
    public void testSetPreference() throws Exception {
        doReturn(pst).when(conn).prepareStatement(any());
        doReturn(result).when(pst).executeQuery();
        doReturn(true).when(result).next();

        DateDatabase uut = new DateDatabase();

        assertEquals(true, uut.setPreference(conn, "username", 1, 1));
    }

    @Test
    public void testSetAvailable() throws Exception {
        doReturn(pst).when(conn).prepareStatement(any());
        doReturn(result).when(pst).executeQuery();
        doReturn(true).when(result).next();

        DateDatabase uut = new DateDatabase();

        assertEquals(true, uut.setAvailable(conn, "username", 1, true));
        assertEquals(true, uut.setAvailable(conn, "username", 1, false));
    }

    @Test
    public void testFinalizeUnauthorized() throws SQLException, UnauthorizedException {
        doReturn(pst).when(conn).prepareStatement(any());
        doReturn(result).when(pst).executeQuery();
        doReturn(false).when(result).next();
        doReturn(112).when(result).getInt("eid");

        DateDatabase uut = new DateDatabase();

        assertThrows(UnauthorizedException.class, () -> uut.finalize(conn, 1, "username"));
    }

    @Test
    public void testFinalizeAllAvailable() throws SQLException, UnauthorizedException {
        doReturn(pst).when(conn).prepareStatement(any());
        doReturn(result).when(pst).executeQuery();
        doAnswer(new Answer<Boolean>() {
            private int count = 0;

            public Boolean answer(InvocationOnMock invocation) {
                count++;
                if (count == 1)
                    return true;
                if (count == 2)
                    return true;
                return false;
            }
        }).when(result).next();
        doReturn(112).when(result).getInt("eid");

        DateDatabase uut = new DateDatabase();

        assertEquals(112, uut.finalize(conn, 1, "username").get(0).getId());
    }

    @Test
    public void testFinalizeNoOneResponded() throws SQLException, UnauthorizedException {
        doReturn(pst).when(conn).prepareStatement(any());
        doReturn(result).when(pst).executeQuery();
        doAnswer(new Answer<Boolean>() {
            private int count = 0;

            public Boolean answer(InvocationOnMock invocation) {
                count++;
                if (count == 1)
                    return true;
                if (count == 3)
                    return true;
                return false;
            }
        }).when(result).next();
        doReturn(112).when(result).getInt("eid");

        DateDatabase uut = new DateDatabase();

        assertEquals(112, uut.finalize(conn, 1, "username").get(0).getId());
    }

    @Test
    public void testSetFinalized() throws SQLException {
        doReturn(pst).when(conn).prepareStatement(any());
        doReturn(result).when(pst).executeQuery();
        doReturn(true).when(result).next();

        DateDatabase uut = new DateDatabase();
        assertEquals(true, uut.setFinalized(conn, 1, 2, "username"));
    }

    @Test
    public void testGetFinalized() throws SQLException, UnauthorizedException {
        DateDatabase uut = mock(DateDatabase.class);
        Date testDate = new Date(1, "proposer", "name", new ArrayList<Event>(), "status",
                new ArrayList<String>());

        doReturn(testDate).when(uut).getDate(any(), anyInt(), any());
        when(uut.getFinalized(any(), any())).thenCallRealMethod();

        doReturn(pst).when(conn).prepareStatement(any());
        doReturn(result).when(pst).executeQuery();
        doAnswer(new Answer<Boolean>() {
            private int count = 0;

            public Boolean answer(InvocationOnMock invocation) {
                if (count++ == 1)
                    return false;
                return true;
            }
        }).when(result).next();

        List<Date> testResult = uut.getFinalized(conn, "h");
        assertEquals(1, testResult.size());
        assertEquals("proposer", testResult.get(0).getProposer());
        assertEquals("name", testResult.get(0).getName());
        assertEquals(new ArrayList<Event>(), testResult.get(0).getEvents());
        assertEquals("status", testResult.get(0).getStatus());
        assertEquals(new ArrayList<String>(), testResult.get(0).getInvitees());
    }

    @Test
    public void testAccept() throws SQLException {
        doReturn(pst).when(conn).prepareStatement(any());
        doReturn(result).when(pst).executeQuery();
        doReturn(true).when(result).next();

        DateDatabase uut = new DateDatabase();

        assertEquals(true, uut.accept(conn, 1, "username"));
    }

    @Test
    public void testDecline() throws SQLException {
        doReturn(pst).when(conn).prepareStatement(any());
        doReturn(result).when(pst).executeQuery();
        doReturn(true).when(result).next();

        DateDatabase uut = new DateDatabase();

        assertEquals(true, uut.decline(conn, 1, "username"));
    }

    @Test
    public void testDeleteDate() throws SQLException {
        doReturn(pst).when(conn).prepareStatement(any());
        doReturn(result).when(pst).executeQuery();
        doReturn(true).when(result).next();

        DateDatabase uut = new DateDatabase();

        assertEquals(true, uut.deleteDate(conn, 1, "username"));
    }

    @Test
    public void testDeleteDateFailure() throws SQLException {
        doReturn(pst).when(conn).prepareStatement(any());
        doReturn(result).when(pst).executeQuery();
        doReturn(false).when(result).next();

        DateDatabase uut = new DateDatabase();

        assertEquals(false, uut.deleteDate(conn, 1, "username"));
    }

    @Test
    public void testDeleteEvent() throws SQLException {
        doReturn(pst).when(conn).prepareStatement(any());
        doReturn(result).when(pst).executeQuery();
        doReturn(true).when(result).next();

        DateDatabase uut = new DateDatabase();

        assertEquals(true, uut.deleteEvent(conn, 1, 1, "username"));
    }

    @Test
    public void testDeleteInvitee() throws SQLException {
        doReturn(pst).when(conn).prepareStatement(any());
        doReturn(result).when(pst).executeQuery();
        doReturn(true).when(result).next();

        DateDatabase uut = new DateDatabase();

        assertEquals(true, uut.deleteInvitee(conn, 1, "username", "username"));
    }

}
