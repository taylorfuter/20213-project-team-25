package csci310.date;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class DateAdvisorTest {
    DateAdvisor uut = new DateAdvisor();

    @Test
    public void testHandleUnauthorized() {
        assertEquals("Unauthorized", uut.handleUnauthorized().getError());
    }

    @Test
    public void testHandleUsernameConflict() {
        assertEquals("this", uut.handleUsernameConflict(new Exception("this")).getError());
    }

    @Test
    public void testHandleEventNotFound() {
        assertEquals("this", uut.handleEventNotFound(new Exception("this")).getError());
    }

    @Test
    public void testHandleInvalidPreference() {
        assertEquals("this", uut.handleInvalidPreference(new Exception("this")).getError());
    }

    @Test
    public void testHandleNoNameSpecified() {
        assertEquals("this", uut.handleNoNameSpecified(new Exception("this")).getError());
    }

    @Test
    public void testHandleSelfInvited() {
        assertEquals("this", uut.handleSelfInvited(new Exception("this")).getError());
    }

    @Test
    public void testHandleDateNotFound() {
        assertEquals("this", uut.handleDateNotFound(new Exception("this")).getError());
    }

}
