package csci310.date;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mockStatic;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import csci310.common.AuthenticateJwt;
import csci310.exception.DateNotFoundException;
import csci310.exception.EventNotFoundException;
import csci310.exception.InvalidPreferenceException;
import csci310.exception.UserNotFoundException;
import csci310.model.Date;
import csci310.model.Event;
import csci310.model.ProposedDate;

public class DateControllerTest {

    DateController uut = new DateController();

    @Mock
    DateDatabase dbUtils;

    AutoCloseable closeable;

    @Before
    public void setup() {
        closeable = MockitoAnnotations.openMocks(this);
    }

    @After
    public void cleanup() throws Exception {
        closeable.close();
    }

    @Test
    public void testProposeRoute() throws Exception {
        Date expected = new Date(1, "proposer", "name", new ArrayList<Event>(), "status", new ArrayList<String>());
        doReturn(expected).when(dbUtils).getDate(any(), anyInt(), any());
        doReturn(1).when(dbUtils).createDate(any(), any(), any(), any(), any());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            Date result = uut.proposeRoute("test this", new ProposedDate("this", new String[] {}, "", new String[] {}));
            assertEquals(expected, result);
        }
    }

    @Test
    public void testProposedRoute() throws Exception {
        DateController uut = new DateController();
        List<Date> expected = new ArrayList<Date>();
        doReturn(expected).when(dbUtils).getProposed(any(), any());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            List<Date> result = uut.proposedRoute("test this");
            assertEquals(expected, result);
        }
    }

    @Test
    public void testInvitedRoute() throws Exception {
        DateController uut = new DateController();
        List<Date> expected = new ArrayList<Date>();
        doReturn(expected).when(dbUtils).getInvited(any(), any());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            List<Date> result = uut.invitedRoute("test this");
            assertEquals(expected, result);
        }
    }

    @Test
    public void testPreferenceRouteSuccess() throws SQLException {
        doReturn(true).when(dbUtils).setPreference(any(), any(), anyInt(), anyInt());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            // No throw
            try {
                uut.preferenceRoute("", 1, 1);
            } catch (Exception e) {
                fail("Unexpected throw");
            }
        }
    }

    @Test
    public void testPreferenceRouteInvalidPreference() throws Exception {
        doReturn(true).when(dbUtils).setPreference(any(), any(), anyInt(), anyInt());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            assertThrows(InvalidPreferenceException.class, () -> uut.preferenceRoute("", 1, 0));
            assertThrows(InvalidPreferenceException.class, () -> uut.preferenceRoute("", 1, 6));
        }
    }

    @Test
    public void testPreferenceRouteEventNotFound() throws Exception {
        doReturn(false).when(dbUtils).setPreference(any(), any(), anyInt(), anyInt());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            assertThrows(EventNotFoundException.class, () -> uut.preferenceRoute("", 1, 1));
        }
    }

    @Test
    public void testAvailableRouteSuccess() throws SQLException {
        doReturn(true).when(dbUtils).setAvailable(any(), any(), anyInt(), anyBoolean());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            // No throw
            try {
                uut.availableRoute("", 1, true);
            } catch (Exception e) {
                fail("Unexpected throw");
            }
        }
    }

    @Test
    public void testAvailableRouteEventNotFound() throws Exception {
        doReturn(false).when(dbUtils).setAvailable(any(), any(), anyInt(), anyBoolean());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            assertThrows(EventNotFoundException.class, () -> uut.availableRoute("", 1, true));
        }
    }

    @Test
    public void testFinalizeRoute() throws Exception {
        List<Event> expected = new ArrayList<Event>();
        doReturn(expected).when(dbUtils).finalize(any(), anyInt(), any());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            assertEquals(expected, uut.finalizeRoute("", 1));
        }
    }

    @Test
    public void testFinalizedRoute() throws Exception {
        List<Date> expected = new ArrayList<Date>();
        doReturn(expected).when(dbUtils).getFinalized(any(), any());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            List<Date> result = uut.finalizedRoute("test this");
            assertEquals(expected, result);
        }
    }

    @Test
    public void testAcceptRoute() throws SQLException {
        doReturn(true).when(dbUtils).accept(any(), anyInt(), any());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            // no throw
            try {
                uut.acceptRoute("token", 1);
            } catch (Exception e) {
                fail("Unexpected throw");
            }
        }
    }

    @Test
    public void testAcceptRouteNotFound() throws SQLException {
        doReturn(false).when(dbUtils).accept(any(), anyInt(), any());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            assertThrows(DateNotFoundException.class, () -> uut.acceptRoute("token", 1));
        }
    }

    @Test
    public void testDeclineRoute() throws SQLException {
        doReturn(true).when(dbUtils).decline(any(), anyInt(), any());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            // no throw
            try {
                uut.declineRoute("token", 1);
            } catch (Exception e) {
                fail("Unexpected throw");
            }
        }
    }

    @Test
    public void testDeclineRouteNotFound() throws SQLException {
        doReturn(false).when(dbUtils).decline(any(), anyInt(), any());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            assertThrows(DateNotFoundException.class, () -> uut.declineRoute("token", 1));
        }
    }

    @Test
    public void testSelectFinalRouteSuccess() throws Exception {
        doReturn(true).when(dbUtils).setFinalized(any(), anyInt(), anyInt(), any());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            // no throw
            try {
                uut.selectFinalRoute("token", 1, 1);
            } catch (Exception e) {
                fail("Unexpected throw");
            }
        }
    }

    @Test
    public void testSelectFinalRouteNotFound() throws Exception {
        doReturn(false).when(dbUtils).setFinalized(any(), anyInt(), anyInt(), any());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            assertThrows(DateNotFoundException.class, () -> uut.selectFinalRoute("token", 1, 1));
        }
    }

    @Test
    public void testDeleteDateRouteSuccess() throws Exception {
        doReturn(true).when(dbUtils).deleteDate(any(), anyInt(), any());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            try {
                uut.deleteDateRoute("token", 1);
            } catch (Exception e) {
                fail("Unexpected throw");
            }
        }
    }

    @Test
    public void testDeleteDateRouteNotFound() throws Exception {
        doReturn(false).when(dbUtils).deleteDate(any(), anyInt(), any());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            assertThrows(DateNotFoundException.class, () -> uut.deleteDateRoute("token", 1));
        }
    }

    @Test
    public void testDeleteEventRouteSuccess() throws Exception {
        doReturn(true).when(dbUtils).deleteEvent(any(), anyInt(), anyInt(), any());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            try {
                uut.deleteEventRoute("token", 1, 1);
            } catch (Exception e) {
                fail("Unexpected throw");
            }
        }
    }

    @Test
    public void testDeleteEventRouteNotFound() throws Exception {
        doReturn(false).when(dbUtils).deleteEvent(any(), anyInt(), anyInt(), any());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            assertThrows(EventNotFoundException.class, () -> uut.deleteEventRoute("token", 1, 1));
        }
    }

    @Test
    public void testDeleteInviteeRouteSuccess() throws Exception {
        doReturn(true).when(dbUtils).deleteInvitee(any(), anyInt(), any(), any());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            try {
                uut.deleteInviteeRoute("token", 1, "username");
            } catch (Exception e) {
                fail("Unexpected throw");
            }
        }
    }

    @Test
    public void testDeleteInviteeRouteNotFound() throws Exception {
        doReturn(false).when(dbUtils).deleteInvitee(any(), anyInt(), any(), any());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            assertThrows(UserNotFoundException.class, () -> uut.deleteInviteeRoute("token", 1, "username"));
        }
    }

}
