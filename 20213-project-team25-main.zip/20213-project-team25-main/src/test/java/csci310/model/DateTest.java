package csci310.model;

import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.assertEquals;

public class DateTest {

    @Test
    public void testGetEvents() {
        Date uut = new Date(1, "proposer", "name", new ArrayList<Event>(), "status", new ArrayList<String>());
        assertEquals(new ArrayList<Event>(), uut.getEvents());
    }

    @Test
    public void testGetId() {
        Date uut = new Date(1, "proposer", "name", new ArrayList<Event>(), "status", new ArrayList<String>());
        assertEquals(1, uut.getId());
    }

    @Test
    public void testGetInvitees() {
        Date uut = new Date(1, "proposer", "name", new ArrayList<Event>(), "status", new ArrayList<String>());
        assertEquals(new ArrayList<String>(), uut.getInvitees());
    }

    @Test
    public void testGetName() {
        Date uut = new Date(1, "proposer", "name", new ArrayList<Event>(), "status", new ArrayList<String>());
        assertEquals("name", uut.getName());
    }

    @Test
    public void testGetProposer() {
        Date uut = new Date(1, "proposer", "name", new ArrayList<Event>(), "status", new ArrayList<String>());
        assertEquals("proposer", uut.getProposer());
    }

    @Test
    public void testGetStatus() {
        Date uut = new Date(1, "proposer", "name", new ArrayList<Event>(), "status", new ArrayList<String>());
        assertEquals("status", uut.getStatus());
    }

    @Test
    public void testSetEvents() {
        Date uut = new Date(1, "proposer", "name", new ArrayList<Event>(), "status", new ArrayList<String>());
        ArrayList<Event> events = new ArrayList<Event>();
        events.add(new Event(1, "this", -1, -1));
        uut.setEvents(events);
        assertEquals(events, uut.getEvents());
    }

    @Test
    public void testSetId() {
        Date uut = new Date(1, "proposer", "name", new ArrayList<Event>(), "status", new ArrayList<String>());
        uut.setId(200);
        assertEquals(200, uut.getId());
    }

    @Test
    public void testSetInvitees() {
        Date uut = new Date(1, "proposer", "name", new ArrayList<Event>(), "status", new ArrayList<String>());
        ArrayList<String> invitees = new ArrayList<String>();
        invitees.add("this");
        uut.setInvitees(invitees);
        assertEquals(invitees, uut.getInvitees());
    }

    @Test
    public void testSetName() {
        Date uut = new Date(1, "proposer", "name", new ArrayList<Event>(), "status", new ArrayList<String>());
        uut.setName("anotherName");
        assertEquals("anotherName", uut.getName());
    }

    @Test
    public void testSetProposer() {
        Date uut = new Date(1, "proposer", "name", new ArrayList<Event>(), "status", new ArrayList<String>());
        uut.setProposer("anotherName");
        assertEquals("anotherName", uut.getProposer());
    }

    @Test
    public void testSetStatus() {
        Date uut = new Date(1, "proposer", "name", new ArrayList<Event>(), "status", new ArrayList<String>());
        uut.setStatus("anotherName");
        assertEquals("anotherName", uut.getStatus());
    }

}
