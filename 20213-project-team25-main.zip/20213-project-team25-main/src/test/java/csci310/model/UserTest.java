package csci310.model;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class UserTest {

    @Test
    public void testGetPassword() {
        User uut = new User("username", "password");
        assertEquals("password", uut.getPassword());
    }

    @Test
    public void testGetUsername() {
        User uut = new User("username", "password");
        assertEquals("username", uut.getUsername());
    }

    @Test
    public void testSetPassword() {
        User uut = new User("username", "password");
        uut.setPassword("another password");
        assertEquals("another password", uut.getPassword());
    }

    @Test
    public void testSetUsername() {
        User uut = new User("username", "password");
        uut.setUsername("another username");
        assertEquals("another username", uut.getUsername());
    }

}
