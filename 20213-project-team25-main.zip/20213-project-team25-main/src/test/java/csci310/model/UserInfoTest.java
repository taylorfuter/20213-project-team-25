package csci310.model;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class UserInfoTest {

    @Test
    public void testGetAvailable() {
        UserInfo uut = new UserInfo(true);
        assertEquals(true, uut.getAvailable());
    }

    @Test
    public void testSetAvailable() {
        UserInfo uut = new UserInfo(true);
        uut.setAvailable(false);
        assertEquals(false, uut.getAvailable());
    }

}
