package csci310.model;

import org.junit.Test;

import java.util.Date;

import static org.junit.Assert.assertEquals;

public class TokenTest {

    @Test
    public void testGetToken() {
        Date date = new Date();
        Token uut = new Token("token", date);
        assertEquals("token", uut.getToken());
    }

    @Test
    public void testGetValidUntil() {
        Date date = new Date();
        Token uut = new Token("token", date);
        assertEquals(date, uut.getValidUntil());
    }

    @Test
    public void testSetToken() {
        Date date = new Date();
        Token uut = new Token("token", date);
        uut.setToken("another token");
        assertEquals("another token", uut.getToken());
    }

    @Test
    public void testSetValidUntil() {
        Date date = new Date();
        Token uut = new Token("token", date);
        Date date2 = new Date(0);
        uut.setValidUntil(date2);
        assertEquals(date2, uut.getValidUntil());
    }

}
