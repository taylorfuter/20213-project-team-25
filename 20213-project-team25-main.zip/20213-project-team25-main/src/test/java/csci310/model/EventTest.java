package csci310.model;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class EventTest {

    @Test
    public void testGetAvailable() {
        Event uut = new Event(1, "tmid", 1, 2);

        assertEquals(Integer.valueOf(2), uut.getAvailable());
    }

    @Test
    public void testGetId() {
        Event uut = new Event(1, "tmid", 1, 2);

        assertEquals(1, uut.getId());
    }

    @Test
    public void testGetTmid() {
        Event uut = new Event(1, "tmid", 1, 2);

        assertEquals("tmid", uut.getTmid());
    }

    @Test
    public void testGetPreference() {
        Event uut = new Event(1, "tmid", 1, 2);

        assertEquals(Integer.valueOf(1), uut.getPreference());
    }

    @Test
    public void testSetAvailable() {
        Event uut = new Event(1, "tmid", 1, 2);
        uut.setAvailable(12);

        assertEquals(Integer.valueOf(12), uut.getAvailable());
    }

    @Test
    public void testSetTmid() {
        Event uut = new Event(1, "tmid", 1, 2);
        uut.setTmid("another");

        assertEquals("another", uut.getTmid());
    }

    @Test
    public void testSetId() {
        Event uut = new Event(1, "tmid", 1, 2);
        uut.setId(112);

        assertEquals(112, uut.getId());
    }

    @Test
    public void testSetPreference() {
        Event uut = new Event(1, "tmid", 1, 2);
        uut.setPreference(12);

        assertEquals(Integer.valueOf(12), uut.getPreference());
    }

}
