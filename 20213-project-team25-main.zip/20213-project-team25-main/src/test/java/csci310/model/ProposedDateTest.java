package csci310.model;

import org.junit.Test;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

public class ProposedDateTest {

    @Test
    public void testGetEvents() {
        ProposedDate uut = new ProposedDate("name", new String[] {}, "status", new String[] {});
        assertArrayEquals(new Event[] {}, uut.getEvents());
    }

    @Test
    public void testGetInvitees() {
        ProposedDate uut = new ProposedDate("name", new String[] {}, "status", new String[] {});
        assertArrayEquals(new String[] {}, uut.getInvitees());
    }

    @Test
    public void testGetName() {
        ProposedDate uut = new ProposedDate("name", new String[] {}, "status", new String[] {});
        assertEquals("name", uut.getName());
    }

    @Test
    public void testGetStatus() {
        ProposedDate uut = new ProposedDate("name", new String[] {}, "status", new String[] {});
        assertEquals("status", uut.getStatus());
    }

    @Test
    public void testSetEvents() {
        ProposedDate uut = new ProposedDate("name", new String[] {}, "status", new String[] {});
        String[] events = new String[] { "this" };
        uut.setEvents(events);
        assertArrayEquals(events, uut.getEvents());
    }

    @Test
    public void testSetInvitees() {
        ProposedDate uut = new ProposedDate("name", new String[] {}, "status", new String[] {});
        String[] invitees = new String[] { "this" };
        uut.setInvitees(invitees);
        assertArrayEquals(invitees, uut.getInvitees());
    }

    @Test
    public void testSetName() {
        ProposedDate uut = new ProposedDate("name", new String[] {}, "status", new String[] {});
        uut.setName("anotherName");
        assertEquals("anotherName", uut.getName());
    }

    @Test
    public void testSetStatus() {
        ProposedDate uut = new ProposedDate("name", new String[] {}, "status", new String[] {});
        uut.setStatus("anotherName");
        assertEquals("anotherName", uut.getStatus());
    }

}
