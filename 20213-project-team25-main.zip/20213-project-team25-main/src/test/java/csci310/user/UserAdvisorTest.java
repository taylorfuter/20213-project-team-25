package csci310.user;

import csci310.common.CommonError;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class UserAdvisorTest {

    @Test
    public void testHandleNoMatch() {
        UserAdvisor uut = new UserAdvisor();
        CommonError error = uut.handleNoMatch(new Exception());
        assertEquals("username or password do not match", error.getError());
    }

    @Test
    public void testHandleUsernameConflict() {
        UserAdvisor uut = new UserAdvisor();
        CommonError error = uut.handleUsernameConflict(new Exception());
        assertEquals("username taken", error.getError());
    }

    @Test
    public void testHandleTooManyTries() {
        UserAdvisor uut = new UserAdvisor();
        CommonError error = uut.handleTooManyTries(new Exception("this"));
        assertEquals("this", error.getError());
    }

    @Test
    public void testHandleUserNotFound() {
        UserAdvisor uut = new UserAdvisor();
        CommonError error = uut.handleUserNotFound(new Exception("this"));
        assertEquals("this", error.getError());
    }

}
