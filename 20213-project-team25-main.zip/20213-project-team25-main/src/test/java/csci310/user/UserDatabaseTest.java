package csci310.user;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;

import csci310.exception.TooManyTries;
import io.lettuce.core.api.StatefulRedisConnection;
import io.lettuce.core.api.sync.RedisCommands;

@RunWith(MockitoJUnitRunner.class)
public class UserDatabaseTest {

    @Mock
    private Connection conn;

    @Mock
    private PreparedStatement pst;

    @Mock
    private ResultSet result;

    @Mock
    private StatefulRedisConnection<String, String> redis;

    @Mock
    RedisCommands<String, String> sync;

    @Captor
    private ArgumentCaptor<String> stringCaptor;

    @Captor
    private ArgumentCaptor<Integer> intCaptor;

    @Captor
    private ArgumentCaptor<Boolean> booleanCaptor;

    AutoCloseable closeable;

    @Before
    public void setup() {
        closeable = MockitoAnnotations.openMocks(this);
    }

    @After
    public void cleanup() throws Exception {
        closeable.close();
    }

    @Test
    public void testLoginSuccess() throws SQLException, TooManyTries {
        UserDatabase uut = new UserDatabase();

        doReturn(pst).when(conn).prepareStatement(anyString());
        doReturn(result).when(pst).executeQuery();
        doReturn(true).when(result).next();
        doReturn(true).when(result).getBoolean(1);
        doReturn(sync).when(redis).sync();
        doReturn(null).when(sync).get(any());

        assertEquals(true, uut.login(conn, redis, "ab", "123"));

        verify(conn, times(1)).prepareStatement(stringCaptor.capture());
        assertEquals("SELECT login(?, ?)", stringCaptor.getValue());
        verify(pst, times(2)).setString(intCaptor.capture(), stringCaptor.capture());
        assertEquals(Integer.valueOf(1), intCaptor.getAllValues().get(0));
        assertEquals(Integer.valueOf(2), intCaptor.getAllValues().get(1));
        assertEquals("ab", stringCaptor.getAllValues().get(1));
        assertEquals("123", stringCaptor.getAllValues().get(2));
        verify(pst, times(1)).executeQuery();
        verify(result, times(1)).next();
        verify(result, times(1)).getBoolean(intCaptor.capture());
        assertEquals(Integer.valueOf(1), intCaptor.getValue());
        verify(sync, times(1)).del("ab");
    }

    @Test
    public void testLoginFailure() throws SQLException, TooManyTries {
        UserDatabase uut = new UserDatabase();

        doReturn(pst).when(conn).prepareStatement(anyString());
        doReturn(result).when(pst).executeQuery();
        doReturn(true).when(result).next();
        doReturn(false).when(result).getBoolean(1);
        doReturn(sync).when(redis).sync();
        doReturn(null).when(sync).get(any());

        assertEquals(false, uut.login(conn, redis, "ab", "123"));

        verify(conn, times(1)).prepareStatement(stringCaptor.capture());
        assertEquals("SELECT login(?, ?)", stringCaptor.getValue());
        verify(pst, times(2)).setString(intCaptor.capture(), stringCaptor.capture());
        assertEquals(Integer.valueOf(1), intCaptor.getAllValues().get(0));
        assertEquals(Integer.valueOf(2), intCaptor.getAllValues().get(1));
        assertEquals("ab", stringCaptor.getAllValues().get(1));
        assertEquals("123", stringCaptor.getAllValues().get(2));
        verify(pst, times(1)).executeQuery();
        verify(result, times(1)).next();
        verify(result, times(1)).getBoolean(intCaptor.capture());
        assertEquals(Integer.valueOf(1), intCaptor.getValue());
    }

    @Test
    public void testLoginBlocked() throws SQLException, TooManyTries {
        UserDatabase uut = new UserDatabase();

        doReturn(sync).when(redis).sync();
        doReturn("blocked").when(sync).get(".ab");

        assertThrows(TooManyTries.class, () -> uut.login(conn, redis, "ab", "123"));
    }

    @Test
    public void testLogin0() throws SQLException, TooManyTries {
        UserDatabase uut = new UserDatabase();

        doReturn(pst).when(conn).prepareStatement(anyString());
        doReturn(result).when(pst).executeQuery();
        doReturn(true).when(result).next();
        doReturn(false).when(result).getBoolean(1);
        doReturn(sync).when(redis).sync();
        doReturn(null).when(sync).get(".ab");
        doReturn(null).when(sync).get("ab");

        assertEquals(false, uut.login(conn, redis, "ab", "123"));

        verify(conn, times(1)).prepareStatement(stringCaptor.capture());
        assertEquals("SELECT login(?, ?)", stringCaptor.getValue());
        verify(pst, times(2)).setString(intCaptor.capture(), stringCaptor.capture());
        assertEquals(Integer.valueOf(1), intCaptor.getAllValues().get(0));
        assertEquals(Integer.valueOf(2), intCaptor.getAllValues().get(1));
        assertEquals("ab", stringCaptor.getAllValues().get(1));
        assertEquals("123", stringCaptor.getAllValues().get(2));
        verify(pst, times(1)).executeQuery();
        verify(result, times(1)).next();
        verify(result, times(1)).getBoolean(intCaptor.capture());
        assertEquals(Integer.valueOf(1), intCaptor.getValue());
        verify(sync, times(1)).set(stringCaptor.capture(), stringCaptor.capture());
        assertEquals("ab", stringCaptor.getAllValues().get(3));
        assertEquals("1", stringCaptor.getAllValues().get(4));
    }

    @Test
    public void testLogin1() throws SQLException, TooManyTries {
        UserDatabase uut = new UserDatabase();

        doReturn(pst).when(conn).prepareStatement(anyString());
        doReturn(result).when(pst).executeQuery();
        doReturn(true).when(result).next();
        doReturn(false).when(result).getBoolean(1);
        doReturn(sync).when(redis).sync();
        doReturn(null).when(sync).get(".ab");
        doReturn("1").when(sync).get("ab");

        assertEquals(false, uut.login(conn, redis, "ab", "123"));

        verify(conn, times(1)).prepareStatement(stringCaptor.capture());
        assertEquals("SELECT login(?, ?)", stringCaptor.getValue());
        verify(pst, times(2)).setString(intCaptor.capture(), stringCaptor.capture());
        assertEquals(Integer.valueOf(1), intCaptor.getAllValues().get(0));
        assertEquals(Integer.valueOf(2), intCaptor.getAllValues().get(1));
        assertEquals("ab", stringCaptor.getAllValues().get(1));
        assertEquals("123", stringCaptor.getAllValues().get(2));
        verify(pst, times(1)).executeQuery();
        verify(result, times(1)).next();
        verify(result, times(1)).getBoolean(intCaptor.capture());
        assertEquals(Integer.valueOf(1), intCaptor.getValue());
        verify(sync, times(1)).set(stringCaptor.capture(), stringCaptor.capture());
        assertEquals("ab", stringCaptor.getAllValues().get(3));
        assertEquals("2", stringCaptor.getAllValues().get(4));
    }

    @Test
    public void testLogin2() throws SQLException, TooManyTries {
        UserDatabase uut = new UserDatabase();

        doReturn(pst).when(conn).prepareStatement(anyString());
        doReturn(result).when(pst).executeQuery();
        doReturn(true).when(result).next();
        doReturn(false).when(result).getBoolean(1);
        doReturn(sync).when(redis).sync();
        doReturn(null).when(sync).get(".ab");
        doReturn("2").when(sync).get("ab");

        assertThrows(TooManyTries.class, () -> uut.login(conn, redis, "ab", "123"));

        verify(conn, times(1)).prepareStatement(stringCaptor.capture());
        assertEquals("SELECT login(?, ?)", stringCaptor.getValue());
        verify(pst, times(2)).setString(intCaptor.capture(), stringCaptor.capture());
        assertEquals(Integer.valueOf(1), intCaptor.getAllValues().get(0));
        assertEquals(Integer.valueOf(2), intCaptor.getAllValues().get(1));
        assertEquals("ab", stringCaptor.getAllValues().get(1));
        assertEquals("123", stringCaptor.getAllValues().get(2));
        verify(pst, times(1)).executeQuery();
        verify(result, times(1)).next();
        verify(result, times(1)).getBoolean(intCaptor.capture());
        assertEquals(Integer.valueOf(1), intCaptor.getValue());
        verify(sync, times(2)).set(stringCaptor.capture(), stringCaptor.capture());
        assertEquals("ab", stringCaptor.getAllValues().get(3));
        assertEquals("3", stringCaptor.getAllValues().get(4));
        assertEquals(".ab", stringCaptor.getAllValues().get(5));
        assertEquals("blocked", stringCaptor.getAllValues().get(6));
    }

    @Test
    public void testLoginCoverage1() throws SQLException, TooManyTries {
        UserDatabase uut = new UserDatabase();

        doReturn(pst).when(conn).prepareStatement(anyString());
        doReturn(result).when(pst).executeQuery();
        doReturn(true).when(result).next();
        doReturn(false).when(result).getBoolean(1);
        doReturn(sync).when(redis).sync();
        doReturn(null).when(sync).get(".ab");
        doReturn("432").when(sync).get("ab");

        assertThrows(TooManyTries.class, () -> uut.login(conn, redis, "ab", "123"));
    }

    @Test
    public void testLoginCoverage2() throws SQLException, TooManyTries {
        UserDatabase uut = new UserDatabase();

        doReturn(pst).when(conn).prepareStatement(anyString());
        doReturn(result).when(pst).executeQuery();
        doReturn(false).when(result).next();
        doReturn(sync).when(redis).sync();
        doReturn(null).when(sync).get(any());

        assertEquals(false, uut.login(conn, redis, "ab", "123"));

        verify(conn, times(1)).prepareStatement(stringCaptor.capture());
        assertEquals("SELECT login(?, ?)", stringCaptor.getValue());
        verify(pst, times(2)).setString(intCaptor.capture(), stringCaptor.capture());
        assertEquals(Integer.valueOf(1), intCaptor.getAllValues().get(0));
        assertEquals(Integer.valueOf(2), intCaptor.getAllValues().get(1));
        assertEquals("ab", stringCaptor.getAllValues().get(1));
        assertEquals("123", stringCaptor.getAllValues().get(2));
        verify(pst, times(1)).executeQuery();
        verify(result, times(1)).next();
    }

    @Test
    public void testSignupSuccess() throws SQLException {
        UserDatabase uut = new UserDatabase();

        doReturn(pst).when(conn).prepareStatement(anyString());
        doReturn(result).when(pst).executeQuery();
        doReturn(true).when(result).next();
        doReturn("success").when(result).getString(1);

        assertEquals("success", uut.signup(conn, "ab", "123"));

        verify(conn, times(1)).prepareStatement(stringCaptor.capture());
        assertEquals("SELECT signup(?, ?)", stringCaptor.getValue());
        verify(pst, times(2)).setString(intCaptor.capture(), stringCaptor.capture());
        assertEquals(Integer.valueOf(1), intCaptor.getAllValues().get(0));
        assertEquals(Integer.valueOf(2), intCaptor.getAllValues().get(1));
        assertEquals("ab", stringCaptor.getAllValues().get(1));
        assertEquals("123", stringCaptor.getAllValues().get(2));
        verify(pst, times(1)).executeQuery();
        verify(result, times(1)).next();
        verify(result, times(1)).getString(intCaptor.capture());
        assertEquals(Integer.valueOf(1), intCaptor.getValue());
    }

    @Test
    public void testSignupFailure() throws SQLException {
        UserDatabase uut = new UserDatabase();

        doReturn(pst).when(conn).prepareStatement(anyString());
        doReturn(result).when(pst).executeQuery();
        doReturn(true).when(result).next();
        doReturn("username exists").when(result).getString(1);

        assertEquals("username exists", uut.signup(conn, "ab", "123"));

        verify(conn, times(1)).prepareStatement(stringCaptor.capture());
        assertEquals("SELECT signup(?, ?)", stringCaptor.getValue());
        assertEquals("SELECT signup(?, ?)", stringCaptor.getValue());
        verify(pst, times(2)).setString(intCaptor.capture(), stringCaptor.capture());
        assertEquals(Integer.valueOf(1), intCaptor.getAllValues().get(0));
        assertEquals(Integer.valueOf(2), intCaptor.getAllValues().get(1));
        assertEquals("ab", stringCaptor.getAllValues().get(1));
        assertEquals("123", stringCaptor.getAllValues().get(2));
        verify(pst, times(1)).executeQuery();
        verify(result, times(1)).next();
        verify(result, times(1)).getString(intCaptor.capture());
        assertEquals(Integer.valueOf(1), intCaptor.getValue());
    }

    @Test
    public void testSignupCoverage() throws SQLException {
        UserDatabase uut = new UserDatabase();

        doReturn(pst).when(conn).prepareStatement(anyString());
        doReturn(result).when(pst).executeQuery();
        doReturn(false).when(result).next();

        assertEquals("unknown error", uut.signup(conn, "ab", "123"));

        verify(conn, times(1)).prepareStatement(stringCaptor.capture());
        assertEquals("SELECT signup(?, ?)", stringCaptor.getValue());
        assertEquals("SELECT signup(?, ?)", stringCaptor.getValue());
        verify(pst, times(2)).setString(intCaptor.capture(), stringCaptor.capture());
        assertEquals(Integer.valueOf(1), intCaptor.getAllValues().get(0));
        assertEquals(Integer.valueOf(2), intCaptor.getAllValues().get(1));
        assertEquals("ab", stringCaptor.getAllValues().get(1));
        assertEquals("123", stringCaptor.getAllValues().get(2));
        verify(pst, times(1)).executeQuery();
        verify(result, times(1)).next();
    }

    @Test
    public void testSetAvailable() throws SQLException {
        UserDatabase uut = new UserDatabase();
        doReturn(pst).when(conn).prepareStatement(anyString());

        uut.setAvailable(conn, "abc", true);
        verify(pst, times(1)).setBoolean(intCaptor.capture(), booleanCaptor.capture());
        assertEquals(true, booleanCaptor.getValue());
        verify(pst, times(1)).setString(intCaptor.capture(), stringCaptor.capture());
        assertEquals("abc", stringCaptor.getValue());
        verify(pst, times(1)).executeUpdate();
    }

    @Test
    public void testGetUserInfoSuccess() throws SQLException {
        UserDatabase uut = new UserDatabase();

        doReturn(pst).when(conn).prepareStatement(anyString());
        doReturn(result).when(pst).executeQuery();
        doReturn(true).when(result).next();
        doReturn(true).when(result).getBoolean("available");

        assertEquals(true, uut.getUserInfo(conn, "username").getAvailable());
    }

    @Test
    public void testGetUserInfoUnexpected() throws SQLException {
        UserDatabase uut = new UserDatabase();

        doReturn(pst).when(conn).prepareStatement(anyString());
        doReturn(result).when(pst).executeQuery();
        doReturn(false).when(result).next();

        assertThrows(SQLException.class, () -> uut.getUserInfo(conn, "username"));
    }

    @Test
    public void testBlockAlreadyBlocked() throws SQLException {
        UserDatabase uut = new UserDatabase();

        doReturn(pst).when(conn).prepareStatement(anyString());
        doReturn(result).when(pst).executeQuery();
        doReturn(true).when(result).next();

        assertEquals("already blocked", uut.block(conn, "username", "toBlock"));
    }

    @Test
    public void testBlockUserNotFound() throws SQLException {
        UserDatabase uut = new UserDatabase();

        doReturn(pst).when(conn).prepareStatement(anyString());
        doReturn(result).when(pst).executeQuery();
        doReturn(false).when(result).next();

        assertEquals("user not found", uut.block(conn, "username", "toBlock"));
    }

    @Test
    public void testBlockSuccess() throws SQLException {
        UserDatabase uut = new UserDatabase();

        doReturn(pst).when(conn).prepareStatement(anyString());
        doReturn(result).when(pst).executeQuery();
        doAnswer(new Answer<Boolean>() {
            private int count = 0;

            public Boolean answer(InvocationOnMock invocation) {
                if (count++ == 1)
                    return true;
                return false;
            }
        }).when(result).next();

        assertEquals("success", uut.block(conn, "username", "toBlock"));
    }

    @Test
    public void testUnblockAlreadyUnblocked() throws SQLException {
        UserDatabase uut = new UserDatabase();

        doReturn(pst).when(conn).prepareStatement(anyString());
        doReturn(result).when(pst).executeQuery();
        doReturn(true).when(result).next();

        assertEquals("already unblocked", uut.unblock(conn, "username", "toBlock"));
    }

    @Test
    public void testUnblockUserNotFound() throws SQLException {
        UserDatabase uut = new UserDatabase();

        doReturn(pst).when(conn).prepareStatement(anyString());
        doReturn(result).when(pst).executeQuery();
        doReturn(false).when(result).next();

        assertEquals("user not found", uut.unblock(conn, "username", "toBlock"));
    }

    @Test
    public void testUnblockSuccess() throws SQLException {
        UserDatabase uut = new UserDatabase();

        doReturn(pst).when(conn).prepareStatement(anyString());
        doReturn(result).when(pst).executeQuery();
        doAnswer(new Answer<Boolean>() {
            private int count = 0;

            public Boolean answer(InvocationOnMock invocation) {
                if (count++ == 1)
                    return true;
                return false;
            }
        }).when(result).next();

        assertEquals("success", uut.unblock(conn, "username", "toBlock"));
    }

    @Test
    public void testAutofill() throws SQLException {
        UserDatabase uut = new UserDatabase();

        doReturn(pst).when(conn).prepareStatement(anyString());
        doReturn(result).when(pst).executeQuery();
        doAnswer(new Answer<Boolean>() {
            private int count = 0;

            public Boolean answer(InvocationOnMock invocation) {
                if (count++ == 1)
                    return false;
                return true;
            }
        }).when(result).next();
        doReturn("this").when(result).getString("username");

        List<String> expected = new ArrayList<String>();
        expected.add("this");
        assertEquals(expected, uut.autofill(conn, "username", "autofill"));
    }

    @Test
    public void testAutofillBlocked() throws SQLException {
        UserDatabase uut = new UserDatabase();

        doReturn(pst).when(conn).prepareStatement(anyString());
        doReturn(result).when(pst).executeQuery();
        doAnswer(new Answer<Boolean>() {
            private int count = 0;

            public Boolean answer(InvocationOnMock invocation) {
                if (count++ == 1)
                    return false;
                return true;
            }
        }).when(result).next();
        doReturn("this").when(result).getString("username");

        List<String> expected = new ArrayList<String>();
        expected.add("this");
        assertEquals(expected, uut.autofillBlocked(conn, "username", "autofill"));
    }

    @Test
    public void testAutofillUnblocked() throws SQLException {
        UserDatabase uut = new UserDatabase();

        doReturn(pst).when(conn).prepareStatement(anyString());
        doReturn(result).when(pst).executeQuery();
        doAnswer(new Answer<Boolean>() {
            private int count = 0;

            public Boolean answer(InvocationOnMock invocation) {
                if (count++ == 1)
                    return false;
                return true;
            }
        }).when(result).next();
        doReturn("this").when(result).getString("username");

        List<String> expected = new ArrayList<String>();
        expected.add("this");
        assertEquals(expected, uut.autofillUnblocked(conn, "username", "autofill"));
    }

}
