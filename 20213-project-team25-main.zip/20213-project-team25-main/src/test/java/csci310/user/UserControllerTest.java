package csci310.user;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import csci310.common.AuthenticateJwt;
import csci310.exception.NoMatchException;
import csci310.exception.TooManyTries;
import csci310.exception.UnauthorizedException;
import csci310.exception.UserNotFoundException;
import csci310.exception.UsernameTakenException;
import csci310.model.Token;
import csci310.model.User;
import csci310.model.UserInfo;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;

public class UserControllerTest {

    @Mock
    UserDatabase dbUtils;

    @Captor
    ArgumentCaptor<String> stringCaptor;

    @Captor
    ArgumentCaptor<Boolean> booleanCaptor;

    AutoCloseable closeable;

    @Before
    public void setup() {
        closeable = MockitoAnnotations.openMocks(this);
    }

    @After
    public void cleanup() throws Exception {
        closeable.close();
    }

    @Test
    public void testLoginRouteSuccess() throws SQLException, TooManyTries {
        UserController uut = new UserController();
        doReturn(true).when(dbUtils).login(any(), any(), any(), any());
        uut.dbUtils = dbUtils;
        try {
            Token result = uut.loginRoute(new User("abc", "123"));
            validateToken(result, "abc");
            verify(dbUtils, times(1)).login(any(), any(), any(), any());
        } catch (Exception e) {
            fail("Unexpected exception:  " + e);
        }
    }

    @Test
    public void testLoginRouteFailure() throws SQLException, TooManyTries {
        UserController uut = new UserController();
        doReturn(false).when(dbUtils).login(any(), any(), any(), any());
        uut.dbUtils = dbUtils;
        try {
            uut.loginRoute(new User("abc", "123"));
            fail("loginRoute should throw NoMatchException");
        } catch (NoMatchException e) {
            return;
        } catch (Exception e) {
            fail("Unexpected exception:  " + e);
        }
    }

    @Test
    public void testSignupRouteSuccess() throws SQLException {
        UserController uut = new UserController();
        doReturn("success").when(dbUtils).signup(any(), any(), any());
        uut.dbUtils = dbUtils;
        try {
            Token result = uut.signupRoute(new User("abc", "123"));
            validateToken(result, "abc");
            verify(dbUtils, times(1)).signup(any(), any(), any());
        } catch (Exception e) {
            fail("Unexpected exception:  " + e);
        }
    }

    @Test
    public void testSignupUsernameExists() throws SQLException {
        UserController uut = new UserController();
        doReturn("username exists").when(dbUtils).signup(any(), any(), any());
        uut.dbUtils = dbUtils;
        try {
            uut.signupRoute(new User("abc", "123"));
            fail("signupRoute should throw UsernameTakenException");
        } catch (UsernameTakenException e) {
            return;
        } catch (Exception e) {
            fail("Unexpected exception:  " + e);
        }
    }

    @Test
    public void testSignupUsernameDot() throws SQLException {
        UserController uut = new UserController();
        doReturn("success").when(dbUtils).signup(any(), any(), any());
        uut.dbUtils = dbUtils;
        try {
            uut.signupRoute(new User(".abc", "123"));
            fail("signupRoute should throw UsernameTakenException");
        } catch (UsernameTakenException e) {
            return;
        } catch (Exception e) {
            fail("Unexpected exception:  " + e);
        }
    }

    @Test
    public void testGetToken() throws Exception {
        UserController uut = new UserController();
        Token token = uut.getToken("ab");
        validateToken(token, "ab");
    }

    private String getJWTSecret() throws FileNotFoundException, Exception {
        Scanner scanner = new Scanner(new File("./.jwtscrt"));
        if (scanner.hasNextLine()) {
            return scanner.nextLine();
        } else {
            throw new Exception("empty secret file");
        }
    }

    private void validateToken(Token token, String username) throws Exception {
        Date now = new Date();
        LocalDateTime expectedDateLow = now.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime().plusHours(11);
        LocalDateTime expectedDateHigh = now.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime().plusHours(13);
        LocalDateTime actual = token.validUntil.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
        assertTrue("validUntil is too early", actual.isAfter(expectedDateLow));
        assertTrue("validUntil is too late", actual.isBefore(expectedDateHigh));

        String secret = getJWTSecret();
        Jws<Claims> jwt = Jwts.parserBuilder().setSigningKey(secret).build().parseClaimsJws(token.token);
        assertEquals(username, jwt.getBody().getSubject());
        Date tokenDate = jwt.getBody().getExpiration();
        actual = tokenDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
        assertTrue("token expiration is too early", actual.isAfter(expectedDateLow));
        assertTrue("token expiration is too late", actual.isBefore(expectedDateHigh));
    }

    @Test
    public void testAvailableRoute() throws UnauthorizedException, SQLException, IOException {
        UserController uut = new UserController();
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            uut.availableRoute("token", true);
            verify(dbUtils, times(1)).setAvailable(any(), stringCaptor.capture(), booleanCaptor.capture());
            assertEquals("test", stringCaptor.getValue());
            assertEquals(true, booleanCaptor.getValue());
        }
    }

    @Test
    public void testUserInfoRoute() throws SQLException, UnauthorizedException, IOException {
        UserController uut = new UserController();
        UserInfo expected = new UserInfo(true);
        doReturn(expected).when(dbUtils).getUserInfo(any(), any());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            UserInfo actual = uut.userInfoRoute("token");
            assertEquals(expected.getAvailable(), actual.getAvailable());
        }
    }

    @Test
    public void testBlockRouteSuccess() throws SQLException {
        UserController uut = new UserController();
        doReturn("success").when(dbUtils).block(any(), any(), any());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            // no throw
            try {
                uut.blockRoute("token", "toBlock");
            } catch (Exception e) {
                fail("Unexpected exception");
            }
        }
    }

    @Test
    public void testBlockRouteUserNotFound() throws SQLException {
        UserController uut = new UserController();
        doReturn("user not found").when(dbUtils).block(any(), any(), any());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            assertThrows(UserNotFoundException.class, () -> uut.blockRoute("token", "toBlock"));
        }
    }

    @Test
    public void testUnblockRouteSuccess() throws SQLException {
        UserController uut = new UserController();
        doReturn("success").when(dbUtils).unblock(any(), any(), any());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            // no throw
            try {
                uut.unblockRoute("token", "toBlock");
            } catch (Exception e) {
                fail("Unexpected exception");
            }
        }
    }

    @Test
    public void testUnblockRouteUserNotFound() throws SQLException {
        UserController uut = new UserController();
        doReturn("user not found").when(dbUtils).unblock(any(), any(), any());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            assertThrows(UserNotFoundException.class, () -> uut.unblockRoute("token", "toBlock"));
        }
    }

    @Test
    public void testAutofillRoute() throws SQLException, IOException, UnauthorizedException {
        UserController uut = new UserController();
        List<String> expected = new ArrayList<String>();
        doReturn(expected).when(dbUtils).autofill(any(), any(), any());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            assertEquals(expected, uut.autofillRoute("token", "autofill"));
        }
    }

    @Test
    public void testAutofillBlockedRoute() throws Exception {
        UserController uut = new UserController();
        List<String> expected = new ArrayList<String>();
        doReturn(expected).when(dbUtils).autofillBlocked(any(), any(), any());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            assertEquals(expected, uut.autofillBlockedRoute("token", "autofill"));
        }
    }

    @Test
    public void testAutofillUnblockedRoute() throws Exception {
        UserController uut = new UserController();
        List<String> expected = new ArrayList<String>();
        doReturn(expected).when(dbUtils).autofillUnblocked(any(), any(), any());
        uut.dbUtils = dbUtils;
        try (MockedStatic<AuthenticateJwt> mockedAuth = mockStatic(AuthenticateJwt.class)) {
            mockedAuth.when(() -> AuthenticateJwt.authenticate(any())).thenReturn("test");
            assertEquals(expected, uut.autofillUnblockedRoute("token", "autofill"));
        }
    }

}
