package csci310;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class GlobalAdvisorTest {

    @Test
    public void testHandleSQLException() {
        GlobalAdvisor uut = new GlobalAdvisor();
        assertEquals("Internal server error. Try again later. SQLException: ", uut.handleSQLException(new Exception("")).getError());
    }

}
