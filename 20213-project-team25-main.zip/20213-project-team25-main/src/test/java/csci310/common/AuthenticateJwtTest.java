package csci310.common;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

import java.io.File;
import java.security.Key;
import java.util.Date;
import java.util.Scanner;

import javax.xml.bind.DatatypeConverter;

import org.junit.Test;

import csci310.exception.UnauthorizedException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

public class AuthenticateJwtTest {

    @Test
    public void testAuthenticate() throws Exception {
        new AuthenticateJwt();
        Scanner scanner = new Scanner(new File("./.jwtscrt"));
        byte[] keyBytes = DatatypeConverter.parseBase64Binary(scanner.nextLine());
        Key signingKey = Keys.hmacShaKeyFor(keyBytes);
        String jws = Jwts.builder().setSubject("test").setExpiration(new Date(System.currentTimeMillis() + 3600 * 1000))
                .signWith(signingKey).compact();
        assertThrows(UnauthorizedException.class, () -> AuthenticateJwt.authenticate(null));
        assertThrows(UnauthorizedException.class, () -> AuthenticateJwt.authenticate(jws));
        assertEquals("test", AuthenticateJwt.authenticate("Bear " + jws));
        assertEquals("test", AuthenticateJwt.authenticate("Bear " + jws));
    }

}
