package csci310.common;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.servlet.config.annotation.CorsRegistration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistration;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

public class CorsConfigTest {

    @Mock
    CorsRegistry cRegistry;

    @Mock
    CorsRegistration cRegistration;

    @Mock
    ViewControllerRegistry vRegistry;

    @Mock
    ViewControllerRegistration vRegistration;

    AutoCloseable closeable;

    @Before
    public void setup() {
        closeable = MockitoAnnotations.openMocks(this);
    }

    @After
    public void cleanup() throws Exception {
        closeable.close();
    }

    @Test
    public void testAddCorsMappings() {
        doReturn(cRegistration).when(cRegistry).addMapping(anyString());
        doReturn(null).when(cRegistration).allowedMethods(anyString(), anyString());
        CorsConfig uut = new CorsConfig();

        uut.addCorsMappings(cRegistry);

        verify(cRegistry, times(1)).addMapping("/**");
        verify(cRegistration, times(1)).allowedMethods("GET", "POST");
    }

    @Test
    public void testAddViewControllers() {
        doReturn(vRegistration).when(vRegistry).addViewController(anyString());
        CorsConfig uut = new CorsConfig();

        uut.addViewControllers(vRegistry);

        verify(vRegistry, times(1)).addViewController("/{spring:\\w+}");
        verify(vRegistry, times(1)).addViewController("/**/{spring:\\w+}");
        verify(vRegistry, times(1)).addViewController("/{spring:\\w+}/**{spring:?!(\\.js|\\.css)$}");
        verify(vRegistration, times(3)).setViewName("forward:/");
    }
}
