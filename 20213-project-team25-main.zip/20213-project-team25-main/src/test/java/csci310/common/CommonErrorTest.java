package csci310.common;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CommonErrorTest {

    @Test
    public void testGetError() {
        CommonError uut = new CommonError("error");
        assertEquals("error", uut.getError());
    }

    @Test
    public void testSetError() {
        CommonError uut = new CommonError("error");
        uut.setError("another error");
        assertEquals("another error", uut.getError());
    }

}
