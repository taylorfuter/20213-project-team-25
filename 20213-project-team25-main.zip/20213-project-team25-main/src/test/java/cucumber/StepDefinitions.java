package cucumber;

import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Step definitions for Cucumber tests.
 */
public class StepDefinitions {

	ChromeOptions options = new ChromeOptions().addArguments("ignore-certificate-errors");

	private final WebDriver driver = new ChromeDriver(options);

	// pages
	@Given("I am on the login page")
	public void i_am_on_the_login_page() {
		driver.get("https://localhost:8080/login");
	}

	@Given("I am on the registration page")
	public void i_am_on_the_registration_page() {
		driver.get("https://localhost:8080/register");
	}

	@Given("I am on the main page")
	public void i_am_on_the_main_page() {
		i_am_on_the_login_page();
		login_enter_username("username");
		login_enter_password("password");
		click_login_button();
	}

	@Given("I am on the main page as {string}")
	public void i_am_on_the_main_page(String name) {
		i_am_on_the_login_page();
		login_enter_username(name);
		login_enter_password("password");
		click_login_button();
	}

	@Given("I am on the propose page")
	public void i_am_on_the_propose_page() {
		i_am_on_the_main_page();
		press_plan_event_button();
	}

	@Given("I am on the propose page as {string}")
	public void i_am_on_the_propose_page(String name) {
		i_am_on_the_login_page();
		login_enter_username(name);
		login_enter_password("password");
		click_login_button();
		press_plan_event_button();
	}

	@Given("I am on the settings page")
	public void click_user_setting() {
		i_am_on_the_main_page();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.cssSelector(
				"#root > section > main > div > div.ant-row.ant-row-space-between > div:nth-child(3) > div > button"))
				.click();
	}

	@Given("I am on the settings page as {string}")
	public void click_user_setting(String name) {
		i_am_on_the_login_page();
		login_enter_username(name);
		login_enter_password("password");
		click_login_button();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.cssSelector(
				"#root > section > main > div > div.ant-row.ant-row-space-between > div:nth-child(3) > div > button"))
				.click();
	}

	// login
	@When("I enter {string} into the username field")
	public void login_enter_username(String loginUsername) {
		WebElement loginUsernameString = driver.findElement(By.id("login_username"));
		loginUsernameString.sendKeys(loginUsername);
	}

	@When("I enter {string} into the password field")
	public void login_enter_password(String loginPwd) {
		WebElement passwordString = driver.findElement(By.id("login_password"));
		passwordString.sendKeys(loginPwd);
	}

	@When("I click the login button")
	public void click_login_button() {
		driver.findElement(By.xpath("//*[@id=\"login\"]/div[4]/div/div/div/button")).click();
	}

	// unsuccessful login
	@Then("I should see an error message and remain on the login page")
	public void login_failed_error_message() {
		String currURL = driver.getCurrentUrl();
		assertEquals("https://localhost:8080/login", currURL);
	}

	// successful login
	@Then("I should see the URL change to main")
	public void url_chnage_to_main() {
		new WebDriverWait(driver, Duration.ofSeconds(20)).until(ExpectedConditions.urlContains("main"));
		String currURL = driver.getCurrentUrl();
		assertEquals("https://localhost:8080/main", currURL);
	}

	// repeated login failures
	@When("I wait for {int} seconds")
	public void i_wait_for_seconds(Integer int1) {
		try {
			Thread.sleep(int1 * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@When("I failed to login for {int} times using {string}")
	public void i_failed_to_login_for_times(Integer int1, String username) {
		String s = Keys.chord(Keys.CONTROL, "a");
		driver.findElement(By.id("login_username")).sendKeys(s);
		login_enter_username(username);
		driver.findElement(By.id("login_password")).sendKeys(s);
		login_enter_password("password1");
		for (int i = 0; i != int1; i++) {
			click_login_button();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	@Then("Login button should be disabled")
	public void login_button_should_be_disabled() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		assertEquals(false, driver.findElement(By.xpath("//*[@id=\"login\"]/div[4]/div/div/div/button")).isEnabled());
	}

	// register
	@When("I enter {string} into the register username field")
	public void register_enter_username(String username) {
		driver.findElement(By.id("register_username")).sendKeys(username);
	}

	@When("I enter {string} into the register password field")
	public void i_create_password1(String pwd) {
		WebElement passwordString = driver.findElement(By.xpath("//*[@id=\"register_password\"]"));
		passwordString.sendKeys(pwd);
	}

	@When("I enter {string} into the confirm password field")
	public void incorrect_verification_password2(String existing_pwd2) {
		WebElement password2String = driver.findElement(By.xpath("//*[@id=\"register_confirm\"]"));
		password2String.sendKeys(existing_pwd2);
	}

	@When("I click the create account button")
	public void click_create_account() {
		driver.findElement(By.xpath("//*[@id=\"register\"]/div[5]/div/div/div/button")).click();
	}

	// empty registration fields
	@Then("I should get three error messages for register")
	public void empty_error_message() {
		try {
			Thread.sleep(3000);
			String errorMessage1 = driver.findElement(By.xpath("//*[@id=\"register\"]/div[1]/div/div[2]/div"))
					.getText();
			String errorMessage2 = driver.findElement(By.xpath("//*[@id=\"register\"]/div[2]/div/div[2]/div"))
					.getText();
			String errorMessage3 = driver.findElement(By.xpath("//*[@id=\"register\"]/div[3]/div/div[2]/div"))
					.getText();
			assertEquals("Please input your username!", errorMessage1);
			assertEquals("Please input your password!", errorMessage2);
			assertEquals("Please confirm your password!", errorMessage3);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	// wrong confirmation password
	// existing username
	@Then("I should see an error message and remain on register page")
	public void i_should_remain_on_register() {
		String currURL = driver.getCurrentUrl();
		assertEquals("https://localhost:8080/register", currURL);
	}

	// logout
	@When("I click the user icon")
	public void i_click_user_icon() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.cssSelector(".groupie-user-avatar")).click();
	}

	@When("I click the logout button")
	public void i_click_logout_button() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.cssSelector(".groupie-logout-button")).click();
	}

	@Then("I should see the URL change to login")
	public void url_change_to_login() {
		new WebDriverWait(driver, Duration.ofSeconds(20)).until(ExpectedConditions.urlContains("login"));
		String currURL = driver.getCurrentUrl();
		assertEquals("https://localhost:8080/login", currURL);
	}

	// propose
	@When("I press the plan a new event button")
	public void press_plan_event_button() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.cssSelector(".groupie-new-event-button")).click();
	}

	@Then("I should see the URL change to propose")
	public void url_change_to_propose() {
		new WebDriverWait(driver, Duration.ofSeconds(20)).until(ExpectedConditions.urlContains("propose"));
		String currURL = driver.getCurrentUrl();
		assertEquals("https://localhost:8080/propose", currURL);
	}

	// propose location
	@When("I click on the location filter")
	public void click_location_filter() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.cssSelector(
				"#ticket-master-table > div > div > div > div > div > div > table > thead > tr > th:nth-child(5) > div > span.ant-dropdown-trigger.ant-table-filter-trigger"))
				.click();
	}

	@When("I type London to the location filter")
	public void type_london_location() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.cssSelector(".groupie-location-filter-input")).sendKeys("London\n");
	}

	@Then("The page should show only events in London")
	public void events_are_in_london() {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		assertTrue("Event is not in London",
				driver.findElement(By.cssSelector(
						"#ticket-master-table > div > div > div > div > div > div > table > tbody > tr:nth-child(1) > td:nth-child(5)"))
						.getText().toLowerCase().contains("london"));
	}

	// propose: date range
	@When("I click on the date range filter")
	public void click_date_range_filter() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.cssSelector(
				"#ticket-master-table > div > div > div > div > div > div > table > thead > tr > th:nth-child(3) > div > span.ant-dropdown-trigger.ant-table-filter-trigger"))
				.click();
	}

	@When("I select the date range from December 3 to December 4")
	public void select_date_range() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		WebElement firstInput = driver.findElement(By.cssSelector(
				"body > div:nth-child(7) > div > div > div > div > div.ant-picker-input.ant-picker-input-active > input"));
		firstInput.sendKeys("2021-12-02");
		WebElement parent = firstInput.findElement(By.xpath("./.."));
		WebElement secondInput = parent.findElement(By.xpath("following-sibling::*[2]/input"));
		secondInput.sendKeys("2021-12-04\n");
		driver.findElement(By.cssSelector(
				"#ticket-master-table > div > div > div > div > div > div > table > thead > tr > th:nth-child(3) > div > span.ant-dropdown-trigger.ant-table-filter-trigger"))
				.click();
	}

	@Then("The page should show only events in the chosen date range")
	public void events_are_in_date_range() {
		String date = driver.findElement(By.cssSelector(
				"#ticket-master-table > div > div > div > div > div > div > table > tbody > tr:nth-child(1) > td:nth-child(3)"))
				.getText();
		assertTrue("Event not in date range",
				date.equals("2021-12-02") || date.equals("2021-12-03") || date.equals("2021-12-04"));
	}

	// propose genre
	@When("I click on the genre filter")
	public void click_genre_filter() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.cssSelector(
				"#ticket-master-table > div > div > div > div > div > div > table > thead > tr > th:nth-child(6) > div > span.ant-dropdown-trigger.ant-table-filter-trigger"))
				.click();
	}

	@When("I select sports from the given list")
	public void select_sports_genre() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.cssSelector(
				"body > div:nth-child(7) > div > div > div > ul > li:nth-child(3) > span > label > span > input"))
				.click();
		driver.findElement(By.cssSelector(
				"body > div:nth-child(7) > div > div > div > div.ant-table-filter-dropdown-btns > button.ant-btn.ant-btn-primary.ant-btn-sm"))
				.click();
	}

	@Then("The page should show only sports events")
	public void events_are_sports() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		assertEquals("Sports", driver.findElement(By.cssSelector(
				"#ticket-master-table > div > div > div > div > div > div > table > tbody > tr:nth-child(1) > td:nth-child(6)"))
				.getText());
	}

	// propose: keyword
	@When("I click on the keyword filter")
	public void click_keyword_filter() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.cssSelector(
				"#ticket-master-table > div > div > div > div > div > div > table > thead > tr > th:nth-child(4) > div > span.ant-dropdown-trigger.ant-table-filter-trigger"))
				.click();
	}

	@When("I enter ball into the keyword section")
	public void enter_ball_to_keyword() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.cssSelector(".groupie-keyword-input")).sendKeys("ball\n");
	}

	@Then("The page should show only events with keyword ball")
	public void events_contain_ball() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		assertTrue("Event does not contain ball", driver.findElement(By.cssSelector(
				"#ticket-master-table > div > div > div > div > div > div > table > tbody > tr:nth-child(1) > td:nth-child(4)"))
				.getText().toLowerCase().contains("ball"));
	}

	// propose: success
	@When("I select the first event listed")
	public void select_first_event() {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.cssSelector(
				"#ticket-master-table > div > div > div > div > div > div > table > tbody > tr:nth-child(1) > td.ant-table-cell.ant-table-selection-column > label > span > input"))
				.click();
	}

	@When("I select the second event listed")
	public void select_second_event() {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		WebElement secondEvent = driver.findElement(By.cssSelector(
				"#ticket-master-table > div > div > div > div > div > div > table > tbody > tr:nth-child(2) > td.ant-table-cell.ant-table-selection-column > label > span > input"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", secondEvent);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		secondEvent.click();
	}

	@When("I click the invite friends button")
	public void click_invite_friends() {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.cssSelector(".inviteFriendsButton")).click();
	}

	@When("I enter {string} in Group Date Name")
	public void enter_group_date_name(String name) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.cssSelector(".groupie-date-name-input")).sendKeys(name);
	}

	@When("I enter {string} in Invitees")
	public void enter_group_invitee_name(String name) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.cssSelector("#dynamic_form_item_names_0")).sendKeys(name);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.cssSelector("#dynamic_form_item_names_0")).sendKeys(Keys.ENTER);
	}

	@When("I click OK on the create date popup")
	public void click_propose_ok() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[2]/div[3]/button[2]")).click();
	}

	@Then("I should see a proposed event {string} on my event list")
	public void see_proposed_event(String name) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.get("https://localhost:8080/main");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.cssSelector(".groupie-proposed-button")).click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		assertEquals(name, driver.findElement(By.cssSelector(
				"#root > section > main > div > div > div.ant-page-header-content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > span.ant-select-selection-item"))
				.getText());
	}

	@When("I click the Invite another friend button")
	public void invite_another_friend() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.cssSelector(".groupie-another-friend")).click();
	}

	@When("I enter {string} in the second Invitees input")
	public void enter_group_invitee_name2(String name) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.cssSelector("#dynamic_form_item_names_1")).sendKeys(name);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.cssSelector("#dynamic_form_item_names_1")).sendKeys(Keys.ENTER);
	}

	// propose: failure
	@Then("I should see an error and stay on the propose page")
	public void propose_error() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		assertEquals(driver.getCurrentUrl(), "https://localhost:8080/propose");
	}

	// view invitations
	@Given("{string} is invited")
	public void given_user_is_invited(String name) {
		i_am_on_the_propose_page();
		select_first_event();
		click_invite_friends();
		enter_group_date_name("test name");
		enter_group_invitee_name("invitee3");
		click_propose_ok();
	}

	@When("I click on the show invitations button")
	public void click_invited_button() {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.cssSelector(
				"#root > section > main > div > div.ant-row.ant-row-space-between > div:nth-child(2) > div > button:nth-child(2)"))
				.click();
	}

	@Then("I should see the URL change to invited")
	public void url_chnage_to_invited() {
		new WebDriverWait(driver, Duration.ofSeconds(20)).until(ExpectedConditions.urlContains("invites/invited"));
		String currURL = driver.getCurrentUrl();
		assertEquals("https://localhost:8080/invites/invited", currURL);
	}

	// block unblock
	@When("I enter {string} into the block new user field")
	public void enter_to_block_user_input(String name) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.cssSelector("#dynamic_form_item_event")).sendKeys(name);
	}

	@When("I click the block button")
	public void click_block_button() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.cssSelector("#dynamic_form_item > button")).click();
	}

	@Then("I should see {string} added to my list of blocked users")
	public void verify_user_is_blocked(String name) {
		assertTrue("User is not blocked", !driver.getPageSource().contains(name));
	}

	@When("{string} is blocked")
	public void user_is_blocked(String name) {
		enter_to_block_user_input(name);
		click_block_button();
	}

	@When("I click the unblock button on {string}")
	public void unblock_user(String name) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.cssSelector(
				"#root > section > main > div > div > div.ant-page-header-content > div > div > div > div > div > div > div > div > table > tbody > tr > td:nth-child(2) > div > div > button"))
				.click();
	}

	@Then("I should see {string} taken off the blocked users list")
	public void verify_user_is_unblocked(String name) {
		assertTrue("User is not unblocked", driver.getPageSource().contains(name));
	}

	// available unavailable
	@When("I am available")
	public void i_am_available() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		if (driver.getPageSource().contains("Unavailable")) {
			click_change_availability();
		}
	}

	@When("I am unavailable")
	public void i_am_unavailable() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		if (driver.getPageSource().contains("Available")) {
			click_change_availability();
		}
	}

	@When("I click on the change availability button")
	public void click_change_availability() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		WebElement change = driver.findElement(
				By.cssSelector("#root > section > main > div > div > div.ant-page-header-content > button"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", change);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		change.click();
	}

	@Then("I should see the user change to unavailable")
	public void verify_unavailable() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		assertTrue("User is not unavailable", driver.getPageSource().contains("Unavailable"));
	}

	@Then("I should see the user change to available")
	public void verify_available() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		assertTrue("User is not available", driver.getPageSource().contains("Available"));
	}

	@When("I press the unfinalized button")
	public void i_press_the_unfinalized_button() {

	}

	@Then("I should only see events that have not been finalized on the events list")
	public void i_should_only_see_events_that_have_not_been_finalized_on_the_events_list() {

	}

	@When("I press the order drop down and I select earliest")
	public void i_press_the_order_drop_down_and_I_select_earliest() {

	}

	@Then("I should see the proposals ordered from earliest first event date to latest first event date")
	public void i_should_see_the_proposals_ordered_from_earliest_first_event_date_to_latest_first_event_date() {

	}

	@When("I press the order drop down and I select latest")
	public void i_press_the_order_drop_down_and_I_select_latest() {

	}

	@Then("I should see the proposals ordered from latest first event date to earliest first event date")
	public void i_should_see_the_proposals_ordered_from_latest_first_event_date_to_earliest_first_event_date() {

	}

	@When("I press the finalized button")
	public void i_press_the_finalized_button() {

	}

	@Then("I should only see events that have been finalized on the events list")
	public void i_should_only_see_events_that_have_been_finalized_on_the_events_list() {

	}

	@Given("I am on the invites page")
	public void i_am_on_the_invites_page() {

	}

	@When("I press the all button")
	public void i_press_the_all_button() {

	}

	@Then("I should only see all events that are finalized and unfinalized")
	public void i_should_only_see_all_events_that_are_finalized_and_unfinalized() {

	}

	@When("I click on the second invitation")
	public void i_click_on_the_second_invitation() {

	}

	@When("I click decline button")
	public void i_click_decline_button() {

	}

	@Then("I should see the decline option highlighted")
	public void i_should_see_the_decline_option_highlighted() {

	}

	@Given("I am on invitations page")
	public void i_am_on_invitations_page() {

	}

	@When("I click the view invitations button")
	public void i_click_the_view_invitations_button() {

	}

	@When("I click the first invitation")
	public void i_click_the_first_invitation() {

	}

	@When("I click the accept button")
	public void i_click_the_accept_button() {

	}

	@Then("I should see the accept option highlighted")
	public void i_should_see_the_accept_option_highlighted() {

	}

	@Given("I am on the calendar page")
	public void i_am_on_the_calendar_page() {

	}

	@When("I click unavailable")
	public void i_click_unavailable() {

	}

	@Then("I should see the proposal show that I am unavailable")
	public void i_should_see_the_proposal_show_that_I_am_unavailable() {

	}

	@When("I click the excitement level dropdown for the first event")
	public void i_click_the_excitement_level_dropdown_for_the_first_event() {

	}

	@When("I click {int}")
	public void i_click(Integer int1) {

	}

	@Then("I should see the proposal show that my excitement level is {int}")
	public void i_should_see_the_proposal_show_that_my_excitement_level_is(Integer int1) {

	}

	@When("I click the availability dropdown for the first event")
	public void i_click_the_availability_dropdown_for_the_first_event() {

	}

	@When("I click available")
	public void i_click_available() {

	}

	@Then("I should see the proposal show that I am available")
	public void i_should_see_the_proposal_show_that_I_am_available() {

	}

	@When("I click on the first event")
	public void i_click_on_the_first_event() {

	}

	@When("I click on the delete button for the first user on the first event and there are more users")
	public void i_click_on_the_delete_button_for_the_first_user_on_the_first_event_and_there_are_more_users() {

	}

	@Then("I should see the user deleted from the event")
	public void i_should_see_the_user_deleted_from_the_event() {

	}

	@When("I click on the delete button for the last user on the first event")
	public void i_click_on_the_delete_button_for_the_last_user_on_the_first_event() {

	}

	@When("I click okay on the confirmation message asking if I am okay with deleting the event")
	public void i_click_okay_on_the_confirmation_message_asking_if_I_am_okay_with_deleting_the_event() {

	}

	@Then("I should see the event deleted from event list")
	public void i_should_see_the_event_deleted_from_event_list() {

	}

	@When("I delete a user and there are no users left on the event")
	public void i_delete_a_user_and_there_are_no_users_left_on_the_event() {

	}

	@When("I go back to the calendar page")
	public void i_go_back_to_the_calendar_page() {

	}

	@Then("I should see the event deleted from the proposed events list")
	public void i_should_see_the_event_deleted_from_the_proposed_events_list() {

	}

	@When("I click on the delete button for the first event")
	public void i_click_on_the_delete_button_for_the_first_event() {

	}

	@Then("I should see the event deleted from the calendar")
	public void i_should_see_the_event_deleted_from_the_calendar() {

	}

	@Given("I am on the proposals page")
	public void i_am_on_the_proposals_page() {

	}

	@When("I click the mark unavailable button")
	public void i_click_the_mark_unavailable_button() {

	}

	@Then("I should the calendar should show me unavailable over those selected dates")
	public void i_should_the_calendar_should_show_me_unavailable_over_those_selected_dates() {

	}

	@When("I highlight dates from December {int} to December {int}")
	public void i_highlight_dates_from_December_to_December(Integer int1, Integer int2) {

	}

	@Then("I should only see events on the calendar that are finalized")
	public void i_should_only_see_events_on_the_calendar_that_are_finalized() {

	}

	@When("I click the finalized events button")
	public void i_click_the_finalized_events_button() {

	}

	@Then("I should only see events on the calendar that are unfinalized")
	public void i_should_only_see_events_on_the_calendar_that_are_unfinalized() {

	}

	@When("I click the unfinalized events button")
	public void i_click_the_unfinalized_events_button() {

	}

	@Then("I should only see all finalized and unfinalized events on the calendar")
	public void i_should_only_see_all_finalized_and_unfinalized_events_on_the_calendar() {

	}

	@When("I click the all events button")
	public void i_click_the_all_events_button() {

	}

	@Then("I should see the calendar for the month of February")
	public void i_should_see_the_calendar_for_the_month_of_February() {

	}

	public void i_click_the_month_dropdown() {

	}

	@When("I click February")
	public void i_click_February() {

	}

	@When("I click the month dropdown")
	public void i_click_month() {

	}

	@When("I click okay on the confirmation message asking if I am okay with deleting the user from the event")
	public void i_click_okay_on_the_confirmation_message_asking_if_I_am_okay_with_deleting_the_user() {

	}

	@After()
	public void after() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.quit();
	}
}
