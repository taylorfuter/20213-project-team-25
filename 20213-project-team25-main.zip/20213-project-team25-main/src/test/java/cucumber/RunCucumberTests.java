package cucumber;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Statement;

import org.apache.ibatis.jdbc.ScriptRunner;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import csci310.GroupDateApp;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.github.bonigarcia.wdm.WebDriverManager;
import io.lettuce.core.api.sync.RedisCommands;

/**
 * Run all the cucumber tests in the current package.
 */
@RunWith(Cucumber.class)
// @CucumberOptions(strict = true, features = {"src/test/resources/cucumber/userSettings.feature" }) //will run only feature files x.feature and y.feature.
@CucumberOptions(strict = true)
public class RunCucumberTests {

	@BeforeClass
	public static void setup() throws Exception {
		GroupDateApp.main(new String[] {});
		String sql = Files.readString(Path.of("./postgres/init.sql"));
		Statement stmt = GroupDateApp.conn.createStatement();
		stmt.executeUpdate(sql);
		ScriptRunner sr = new ScriptRunner(GroupDateApp.conn);
		Reader reader = new BufferedReader(new FileReader("./postgres/bootstrap.sql"));
		sr.runScript(reader);
		RedisCommands<String, String> sync = GroupDateApp.redis.sync();
		sync.flushall();
		WebDriverManager.chromedriver().setup();
	}

}
