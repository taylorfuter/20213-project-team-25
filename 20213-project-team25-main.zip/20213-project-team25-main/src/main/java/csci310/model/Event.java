package csci310.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;

public class Event {
    @JsonCreator
    public Event(@JsonProperty("id") int id, @JsonProperty("tmid") String tmid,
            @JsonProperty("preference") int preference, @JsonProperty("available") int available) {
        this.id = id;
        this.tmid = tmid;
        this.preference = preference;
        this.available = available;
    }

    @JsonGetter("id")
    public int getId() {
        return id;
    }

    @JsonSetter("id")
    public void setId(int id) {
        this.id = id;
    }

    public int id;

    @JsonGetter("tmid")
    public String getTmid() {
        return tmid;
    }

    @JsonSetter("tmid")
    public void setTmid(String tmid) {
        this.tmid = tmid;
    }

    public String tmid;

    @JsonGetter("preference")
    public Integer getPreference() {
        return preference;
    }

    @JsonSetter("preference")
    public void setPreference(Integer pref) {
        this.preference = pref;
    }

    public Integer preference;

    @JsonGetter("available")
    public Integer getAvailable() {
        return available;
    }

    @JsonSetter("available")
    public void setAvailable(Integer available) {
        this.available = available;
    }

    public Integer available;
}
