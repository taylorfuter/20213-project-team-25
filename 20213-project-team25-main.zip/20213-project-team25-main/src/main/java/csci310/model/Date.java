package csci310.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;

import java.util.List;

public class Date {
    @JsonCreator
    public Date(@JsonProperty("id") int id, @JsonProperty("proposer") String proposer,
            @JsonProperty("name") String name, @JsonProperty("events") List<Event> events,
            @JsonProperty("status") String status, @JsonProperty("invitees") List<String> invitees) {
        this.id = id;
        this.proposer = proposer;
        this.name = name;
        this.events = events;
        this.status = status;
        this.invitees = invitees;
    }

    @JsonGetter("id")
    public int getId() {
        return id;
    }

    @JsonSetter("id")
    public void setId(int id) {
        this.id = id;
    }

    public int id;

    @JsonGetter("proposer")
    public String getProposer() {
        return proposer;
    }

    @JsonSetter("proposer")
    public void setProposer(String proposer) {
        this.proposer = proposer;
    }

    public String proposer;

    @JsonGetter("name")
    public String getName() {
        return name;
    }

    @JsonSetter("name")
    public void setName(String name) {
        this.name = name;
    }

    public String name;

    @JsonGetter("events")
    public List<Event> getEvents() {
        return events;
    }

    @JsonSetter("events")
    public void setEvents(List<Event> events) {
        this.events = events;
    }

    public List<Event> events;

    @JsonGetter("status")
    public String getStatus() {
        return status;
    }

    @JsonSetter("status")
    public void setStatus(String status) {
        this.status = status;
    }

    public String status;

    @JsonGetter("invitees")
    public List<String> getInvitees() {
        return invitees;
    }

    @JsonSetter("invitees")
    public void setInvitees(List<String> invitees) {
        this.invitees = invitees;
    }

    public List<String> invitees;
}
