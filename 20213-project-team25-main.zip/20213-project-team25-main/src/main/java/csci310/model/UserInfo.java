package csci310.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;

public class UserInfo {

    @JsonCreator
    public UserInfo(@JsonProperty("available") boolean available) {
        this.available = available;
    }

    @JsonGetter("available")
    public boolean getAvailable() {
        return available;
    }

    @JsonSetter("available")
    public void setAvailable(boolean available) {
        this.available = available;
    }

    public boolean available;

}
