package csci310.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonSetter;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

public class Token {

    @JsonCreator
    public Token(String token, Date validUntil) {
        this.token = token;
        this.validUntil = validUntil;
    }

    @JsonGetter("token")
    public String getToken() {
        return token;
    }

    @JsonSetter("token")
    public void setToken(String token) {
        this.token = token;
    }

    public String token;

    @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    @JsonGetter("validUntil")
    public Date getValidUntil() {
        return validUntil;
    }

    @JsonSetter("validUntil")
    public void setValidUntil(Date validUntil) {
        this.validUntil = validUntil;
    }

    public Date validUntil;

}
