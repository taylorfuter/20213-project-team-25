package csci310.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;

public class ProposedDate {
    @JsonCreator
    public ProposedDate(@JsonProperty("name") String name, @JsonProperty("events") String[] events,
            @JsonProperty("status") String status, @JsonProperty("invitees") String[] invitees) {
        this.name = name;
        this.events = events;
        this.status = status;
        this.invitees = invitees;
    }

    @JsonGetter("name")
    public String getName() {
        return name;
    }

    @JsonSetter("name")
    public void setName(String name) {
        this.name = name;
    }

    public String name;

    @JsonGetter("events")
    public String[] getEvents() {
        return events;
    }

    @JsonSetter("events")
    public void setEvents(String[] events) {
        this.events = events;
    }

    public String[] events;

    @JsonGetter("status")
    public String getStatus() {
        return status;
    }

    @JsonSetter("status")
    public void setStatus(String status) {
        this.status = status;
    }

    public String status = "ongoing";

    @JsonGetter("invitees")
    public String[] getInvitees() {
        return invitees;
    }

    @JsonSetter("invitees")
    public void setInvitees(String[] invitees) {
        this.invitees = invitees;
    }

    public String[] invitees;
}
