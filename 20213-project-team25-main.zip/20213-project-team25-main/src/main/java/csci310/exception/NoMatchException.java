package csci310.exception;

public class NoMatchException extends Exception {

    public NoMatchException() {
        super("username and password do not match");
    }

}
