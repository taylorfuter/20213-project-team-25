package csci310.exception;

public class UnauthorizedException extends Exception {

    public UnauthorizedException() {
        super("Unauthorized");
    }

}
