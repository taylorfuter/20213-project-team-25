package csci310.exception;

public class UsernameTakenException extends Exception {
    public UsernameTakenException() {
        super("username taken");
    }
}
