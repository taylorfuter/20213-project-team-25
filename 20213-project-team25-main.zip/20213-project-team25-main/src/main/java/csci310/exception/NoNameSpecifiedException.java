package csci310.exception;

public class NoNameSpecifiedException extends Exception {

    public NoNameSpecifiedException() {
        super("No name is specified");
    }

}
