package csci310.exception;

public class DateNotFoundException extends Exception {

    public DateNotFoundException() {
        super("Specified date not found or is not finalized");
    }
}
