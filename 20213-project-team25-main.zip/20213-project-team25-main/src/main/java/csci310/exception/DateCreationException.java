package csci310.exception;

public class DateCreationException extends Exception {

    public DateCreationException(String err) {
        super(err);
    }

}
