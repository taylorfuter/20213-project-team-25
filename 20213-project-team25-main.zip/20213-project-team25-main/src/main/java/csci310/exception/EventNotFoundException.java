package csci310.exception;

public class EventNotFoundException extends Exception {

    public EventNotFoundException() {
        super("Event not found by the given eid");
    }

}
