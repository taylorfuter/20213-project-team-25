package csci310.exception;

public class TooManyTries extends Exception {

    public TooManyTries() {
        super("Too many failed logins");
    }
}
