package csci310.exception;

public class SelfInvitedException extends Exception {

    public SelfInvitedException() {
        super("Cannot invite yourself");
    }

}
