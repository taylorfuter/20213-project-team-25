package csci310.exception;

public class InvalidPreferenceException extends Exception {

    public InvalidPreferenceException() {
        super("Given preference value is invalid");
    }

}
