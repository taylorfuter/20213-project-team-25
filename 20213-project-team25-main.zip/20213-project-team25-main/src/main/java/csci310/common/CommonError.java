package csci310.common;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonSetter;

public class CommonError {

    @JsonCreator
    public CommonError(String error) {
        this.error = error;
    }

    @JsonGetter("error")
    public String getError() {
        return error;
    }

    @JsonSetter("error")
    public void setError(String error) {
        this.error = error;
    }

    String error;

}
