package csci310.common;

import csci310.exception.UnauthorizedException;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class AuthenticateJwt {

    private static String secret = null;

    public static String authenticate(String token) throws UnauthorizedException, IOException {
        if (token == null)
            throw new UnauthorizedException();
        String[] tokenFields = token.split(" ");
        if (tokenFields.length < 2) {
            throw new UnauthorizedException();
        }
        token = token.split(" ")[1];
        if (secret == null) {
            try (Scanner scanner = new Scanner(new File("./.jwtscrt"))) {
                secret = scanner.nextLine();
            }
        }
        Jws<Claims> jwt = Jwts.parserBuilder().setSigningKey(secret).build().parseClaimsJws(token);
        return jwt.getBody().getSubject();
    }

}
