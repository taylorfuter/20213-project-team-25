package csci310.user;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import csci310.common.CommonError;
import csci310.exception.NoMatchException;
import csci310.exception.TooManyTries;
import csci310.exception.UserNotFoundException;
import csci310.exception.UsernameTakenException;

@ControllerAdvice
public class UserAdvisor extends ResponseEntityExceptionHandler {

    @ResponseStatus(HttpStatus.CONFLICT)
    @ExceptionHandler(UsernameTakenException.class)
    @ResponseBody
    public CommonError handleUsernameConflict(Exception ex) {
        return new CommonError("username taken");
    }

    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ExceptionHandler(NoMatchException.class)
    @ResponseBody
    public CommonError handleNoMatch(Exception ex) {
        return new CommonError("username or password do not match");
    }

    @ResponseStatus(HttpStatus.TOO_MANY_REQUESTS)
    @ExceptionHandler(TooManyTries.class)
    @ResponseBody
    public CommonError handleTooManyTries(Exception ex) {
        return new CommonError(ex.getMessage());
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(UserNotFoundException.class)
    @ResponseBody
    public CommonError handleUserNotFound(Exception ex) {
        return new CommonError(ex.getMessage());
    }

}
