package csci310.user;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.Key;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import javax.xml.bind.DatatypeConverter;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import csci310.GroupDateApp;
import csci310.common.AuthenticateJwt;
import csci310.exception.NoMatchException;
import csci310.exception.TooManyTries;
import csci310.exception.UnauthorizedException;
import csci310.exception.UserNotFoundException;
import csci310.exception.UsernameTakenException;
import csci310.model.Token;
import csci310.model.User;
import csci310.model.UserInfo;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

@RestController
@RequestMapping(value = "/api/user")
@CrossOrigin()
public class UserController {

    UserDatabase dbUtils = new UserDatabase();

    @GetMapping("/info")
    public UserInfo userInfoRoute(@RequestHeader(value = "Authorization", required = true) String token)
            throws UnauthorizedException, IOException, SQLException {
        String username = AuthenticateJwt.authenticate(token);
        return dbUtils.getUserInfo(GroupDateApp.conn, username);
    }

    @PostMapping("/login")
    public Token loginRoute(@RequestBody User user)
            throws SQLException, NoMatchException, FileNotFoundException, TooManyTries {
        if (dbUtils.login(GroupDateApp.conn, GroupDateApp.redis, user.username, user.password)) {
            return getToken(user.username);
        } else {
            throw new NoMatchException();
        }
    }

    @PostMapping("/signup")
    public Token signupRoute(@RequestBody User user)
            throws SQLException, UsernameTakenException, FileNotFoundException {
        if (user.username.startsWith(".")) {
            throw new UsernameTakenException();
        }
        String result = dbUtils.signup(GroupDateApp.conn, user.username, user.password);
        if (result.equals("success")) {
            return getToken(user.username);
        } else {
            throw new UsernameTakenException();
        }
    }

    @PostMapping("/available")
    public void availableRoute(@RequestHeader(value = "Authorization", required = true) String token,
            @RequestParam("available") boolean available) throws UnauthorizedException, SQLException, IOException {
        String username = AuthenticateJwt.authenticate(token);
        dbUtils.setAvailable(GroupDateApp.conn, username, available);
    }

    @PostMapping("/block")
    public void blockRoute(@RequestHeader(value = "Authorization", required = true) String token,
            @RequestParam("username") String toBlock)
            throws UnauthorizedException, IOException, SQLException, UserNotFoundException {
        String username = AuthenticateJwt.authenticate(token);
        String result = dbUtils.block(GroupDateApp.conn, username, toBlock);
        if (result.equals("user not found")) {
            throw new UserNotFoundException();
        }
    }

    @PostMapping("/unblock")
    public void unblockRoute(@RequestHeader(value = "Authorization", required = true) String token,
            @RequestParam("username") String toUnblock)
            throws UnauthorizedException, IOException, SQLException, UserNotFoundException {
        String username = AuthenticateJwt.authenticate(token);
        String result = dbUtils.unblock(GroupDateApp.conn, username, toUnblock);
        if (result.equals("user not found")) {
            throw new UserNotFoundException();
        }
    }

    @GetMapping("/autofill")
    public List<String> autofillRoute(@RequestHeader(value = "Authorization", required = true) String token,
            @RequestParam("username") String autofill) throws UnauthorizedException, IOException, SQLException {
        String username = AuthenticateJwt.authenticate(token);
        return dbUtils.autofill(GroupDateApp.conn, username, autofill);
    }

    @GetMapping("/blocked")
    public List<String> autofillBlockedRoute(@RequestHeader(value = "Authorization", required = true) String token,
            @RequestParam("username") String autofill) throws UnauthorizedException, IOException, SQLException {
        String username = AuthenticateJwt.authenticate(token);
        return dbUtils.autofillBlocked(GroupDateApp.conn, username, autofill);
    }

    @GetMapping("/unblocked")
    public List<String> autofillUnblockedRoute(@RequestHeader(value = "Authorization", required = true) String token,
            @RequestParam("username") String autofill) throws UnauthorizedException, IOException, SQLException {
        String username = AuthenticateJwt.authenticate(token);
        return dbUtils.autofillUnblocked(GroupDateApp.conn, username, autofill);
    }

    Token getToken(String username) throws FileNotFoundException {
        Date validUntil = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(validUntil);
        calendar.add(Calendar.HOUR_OF_DAY, 12);
        validUntil = calendar.getTime();

        Scanner scanner = new Scanner(new File("./.jwtscrt"));
        byte[] keyBytes = DatatypeConverter.parseBase64Binary(scanner.nextLine());
        Key signingKey = Keys.hmacShaKeyFor(keyBytes);
        String jws = Jwts.builder().setSubject(username).setExpiration(validUntil).signWith(signingKey).compact();
        return new Token(jws, validUntil);
    }

}
