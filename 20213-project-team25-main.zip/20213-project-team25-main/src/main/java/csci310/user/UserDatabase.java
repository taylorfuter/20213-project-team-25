package csci310.user;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import csci310.exception.TooManyTries;
import csci310.model.UserInfo;
import io.lettuce.core.api.StatefulRedisConnection;
import io.lettuce.core.api.sync.RedisCommands;

public class UserDatabase {

	public boolean login(Connection conn, StatefulRedisConnection<String, String> redis, String username,
			String password) throws SQLException, TooManyTries {
		RedisCommands<String, String> sync = redis.sync();
		String blocked = sync.get("." + username);
		if (blocked != null) {
			sync.expire("." + username, 59);
			throw new TooManyTries();
		}
		String query = "SELECT login(?, ?)";
		PreparedStatement ps;
		ResultSet result = null;
		ps = conn.prepareStatement(query);
		ps.setString(1, username);
		ps.setString(2, password);
		result = ps.executeQuery();
		if (result.next())
			if (result.getBoolean(1)) {
				sync.del(username);
				return true;
			} else {
				String tries = sync.get(username);
				if (tries == null) {
					sync.set(username, "1");
					return false;
				}
				switch (tries) {
				case "1":
					sync.set(username, "2");
					return false;
				case "2":
					sync.set(username, "3");
					sync.set("." + username, "blocked");
					sync.expire("." + username, 59);
					throw new TooManyTries();
				default:
					throw new TooManyTries();
				}
			}
		return false;
	}

	public String signup(Connection conn, String username, String password) throws SQLException {
		String query = "SELECT signup(?, ?)";
		PreparedStatement ps;
		ResultSet result = null;
		ps = conn.prepareStatement(query);
		ps.setString(1, username);
		ps.setString(2, password);
		result = ps.executeQuery();
		if (result.next())
			return (result.getString(1));
		return "unknown error";
	}

	public void setAvailable(Connection conn, String username, boolean available) throws SQLException {
		String query = "UPDATE users SET available = ? WHERE username = ?";
		PreparedStatement pst = conn.prepareStatement(query);
		pst.setBoolean(1, available);
		pst.setString(2, username);
		pst.executeUpdate();
	}

	public UserInfo getUserInfo(Connection conn, String username) throws SQLException {
		PreparedStatement pst = conn.prepareStatement("SELECT available FROM users WHERE username = ?");
		pst.setString(1, username);
		ResultSet result = pst.executeQuery();
		if (result.next()) {
			return new UserInfo(result.getBoolean("available"));
		}
		throw new SQLException("Unexpected: user not found");
	}

	public String block(Connection conn, String username, String toBlock) throws SQLException {
		PreparedStatement pst = conn.prepareStatement(
				"SELECT blocked_users.uid FROM blocked_users" + " JOIN users AS u ON u.uid = blocked_users.uid"
						+ " JOIN users AS bu ON bu.uid = blocked_uid" + " WHERE u.username = ? AND bu.username = ?");
		pst.setString(1, username);
		pst.setString(2, toBlock);
		ResultSet result = pst.executeQuery();
		if (result.next()) {
			return "already blocked";
		}
		pst = conn.prepareStatement("INSERT INTO blocked_users (uid, blocked_uid)"
				+ " SELECT u.uid, bu.uid AS blocked_uid" + " FROM users AS u, users AS bu"
				+ " WHERE u.username = ? AND bu.username = ?" + " RETURNING blocked_users.uid");
		pst.setString(1, username);
		pst.setString(2, toBlock);
		result = pst.executeQuery();
		if (result.next()) {
			return "success";
		} else {
			return "user not found";
		}
	}

	public String unblock(Connection conn, String username, String toUnblock) throws SQLException {
		PreparedStatement pst = conn.prepareStatement("SELECT uid FROM users" + " WHERE username = ?"
				+ " AND uid NOT IN"
				+ " (SELECT blocked_uid FROM blocked_users JOIN users ON blocked_users.uid = users.uid WHERE username = ?)");
		pst.setString(1, toUnblock);
		pst.setString(2, username);
		ResultSet result = pst.executeQuery();
		if (result.next()) {
			return "already unblocked";
		}
		pst = conn.prepareStatement(
				"DELETE FROM blocked_users" + " WHERE uid = (SELECT uid FROM users WHERE username = ?)"
						+ " AND blocked_uid = (SELECT uid FROM users WHERE username = ?)" + " RETURNING uid");
		pst.setString(1, username);
		pst.setString(2, toUnblock);
		result = pst.executeQuery();
		if (result.next()) {
			return "success";
		} else {
			return "user not found";
		}
	}

	public List<String> autofill(Connection conn, String username, String autofill) throws SQLException {
		autofill += "%";
		PreparedStatement pst = conn.prepareStatement("SELECT username FROM users WHERE username LIKE ?"
				+ " AND username != ?" + " AND available" + " AND uid NOT IN"
				+ " (SELECT blocked_uid FROM blocked_users JOIN users ON blocked_users.uid = users.uid WHERE username = ?)"
				+ " LIMIT 5");
		pst.setString(1, autofill);
		pst.setString(2, username);
		pst.setString(3, username);
		ResultSet result = pst.executeQuery();
		ArrayList<String> autofills = new ArrayList<String>();
		while (result.next()) {
			autofills.add(result.getString("username"));
		}
		return autofills;
	}

	public List<String> autofillBlocked(Connection conn, String username, String autofill) throws SQLException {
		autofill += "%";
		PreparedStatement pst = conn.prepareStatement("SELECT username FROM users WHERE username LIKE ?"
				+ " AND username != ?" + " AND uid IN"
				+ " (SELECT blocked_uid FROM blocked_users JOIN users ON blocked_users.uid = users.uid WHERE username = ?)"
				+ " LIMIT 5");
		pst.setString(1, autofill);
		pst.setString(2, username);
		pst.setString(3, username);
		ResultSet result = pst.executeQuery();
		ArrayList<String> autofills = new ArrayList<String>();
		while (result.next()) {
			autofills.add(result.getString("username"));
		}
		return autofills;
	}

	public List<String> autofillUnblocked(Connection conn, String username, String autofill) throws SQLException {
		autofill += "%";
		PreparedStatement pst = conn.prepareStatement("SELECT username FROM users WHERE username LIKE ?"
				+ " AND username != ?" + " AND uid NOT IN"
				+ " (SELECT blocked_uid FROM blocked_users JOIN users ON blocked_users.uid = users.uid WHERE username = ?)"
				+ " LIMIT 5");
		pst.setString(1, autofill);
		pst.setString(2, username);
		pst.setString(3, username);
		ResultSet result = pst.executeQuery();
		ArrayList<String> autofills = new ArrayList<String>();
		while (result.next()) {
			autofills.add(result.getString("username"));
		}
		return autofills;
	}

}