package csci310;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.ConfigurableApplicationContext;

import io.lettuce.core.RedisClient;
import io.lettuce.core.api.StatefulRedisConnection;

@SpringBootApplication
public class GroupDateApp extends SpringBootServletInitializer {

    public static ConfigurableApplicationContext context = null;

    public static Connection conn = null;

    public static StatefulRedisConnection<String, String> redis;

    public static void main(String[] args) throws Exception {
        // Connect to DB
        String url;
        url = "jdbc:postgresql://postgres:5432/postgres";
        String pwd;
        pwd = getPassword();
        conn = DriverManager.getConnection(url, "postgres", pwd);

        // Connect to Redis
        RedisClient client = RedisClient.create("redis://redis");
        redis = client.connect();

        SpringApplication application = new SpringApplication(GroupDateApp.class);
        application.setAdditionalProfiles("ssl");
        context = application.run(args);
    }

    static String getPassword() throws Exception {
        Scanner scanner;
        try {
            scanner = new Scanner(new File(".dbpwd"));
        } catch (FileNotFoundException e) {
            throw new Exception("Failed to find the password file.");
        }
        String input;
        if (scanner.hasNextLine()) {
            input = scanner.nextLine();
        } else {
            throw new Exception("Database password file is empty.");
        }
        String[] parts = input.split("=");
        if (parts.length < 2) {
            return "";
        } else {
            return parts[1];
        }
    }
}
