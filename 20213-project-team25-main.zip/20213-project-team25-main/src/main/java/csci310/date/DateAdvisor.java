package csci310.date;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import csci310.common.CommonError;
import csci310.exception.DateCreationException;
import csci310.exception.DateNotFoundException;
import csci310.exception.EventNotFoundException;
import csci310.exception.InvalidPreferenceException;
import csci310.exception.NoNameSpecifiedException;
import csci310.exception.SelfInvitedException;
import csci310.exception.UnauthorizedException;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.UnsupportedJwtException;
import io.jsonwebtoken.security.SignatureException;

@ControllerAdvice
public class DateAdvisor {

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(DateCreationException.class)
    @ResponseBody
    public CommonError handleUsernameConflict(Exception ex) {
        return new CommonError(ex.getMessage());
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(SelfInvitedException.class)
    @ResponseBody
    public CommonError handleSelfInvited(Exception ex) {
        return new CommonError(ex.getMessage());
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(InvalidPreferenceException.class)
    @ResponseBody
    public CommonError handleInvalidPreference(Exception ex) {
        return new CommonError(ex.getMessage());
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(EventNotFoundException.class)
    @ResponseBody
    public CommonError handleEventNotFound(Exception ex) {
        return new CommonError(ex.getMessage());
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(NoNameSpecifiedException.class)
    @ResponseBody
    public CommonError handleNoNameSpecified(Exception ex) {
        return new CommonError(ex.getMessage());
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(DateNotFoundException.class)
    @ResponseBody
    public CommonError handleDateNotFound(Exception ex) {
        return new CommonError(ex.getMessage());
    }

    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ExceptionHandler({ UnauthorizedException.class, ExpiredJwtException.class, UnsupportedJwtException.class,
            MalformedJwtException.class, SignatureException.class, IllegalArgumentException.class })
    @ResponseBody
    public CommonError handleUnauthorized() {
        return new CommonError("Unauthorized");
    }

}
