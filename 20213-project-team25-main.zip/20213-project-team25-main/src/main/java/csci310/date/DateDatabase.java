package csci310.date;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import csci310.exception.DateCreationException;
import csci310.exception.NoNameSpecifiedException;
import csci310.exception.SelfInvitedException;
import csci310.exception.UnauthorizedException;
import csci310.model.Date;
import csci310.model.Event;

public class DateDatabase {

    public int createDate(Connection conn, String dateName, String proposer, String[] events, String[] invitees)
            throws DateCreationException, SQLException, SelfInvitedException, NoNameSpecifiedException {
        if (events.length == 0) {
            throw new DateCreationException("No events specified");
        }
        if (Arrays.asList(invitees).contains(proposer)) {
            throw new SelfInvitedException();
        }
        if (invitees.length == 0) {
            throw new DateCreationException("No one invited");
        }
        if (dateName == null) {
            throw new NoNameSpecifiedException();
        }
        invitees = Arrays.copyOf(invitees, invitees.length + 1);
        invitees[invitees.length - 1] = proposer;
        StringBuilder builder = new StringBuilder();
        builder.append("SELECT msg, date_id FROM createDate(?, ?, ARRAY[");
        for (int i = 0; i != events.length - 1; i++) {
            builder.append("?, ");
        }
        builder.append("?], ARRAY[");
        for (int i = 0; i != invitees.length - 1; i++) {
            builder.append("?, ");
        }
        builder.append("?])");

        PreparedStatement pst = conn.prepareStatement(builder.toString());
        pst.setString(1, dateName);
        pst.setString(2, proposer);
        int index = 3;
        for (String event : events) {
            pst.setString(index++, event);
        }
        for (String invitee : invitees) {
            pst.setString(index++, invitee);
        }
        ResultSet result = pst.executeQuery();
        if (result.next()) {
            if (result.getString("msg").equals("success")) {
                return result.getInt("date_id");
            }
            throw new DateCreationException(result.getString("msg"));
        } else {
            throw new DateCreationException("unknown error");
        }
    }

    public Date getDate(Connection conn, int dateId, String username) throws SQLException, UnauthorizedException {
        int userId = getUserOfDate(conn, dateId, username);
        PreparedStatement pst = conn.prepareStatement("SELECT dates.did, up.username AS proposer, date_name, status"
                + " FROM dates JOIN user_date ON user_date.did = dates.did"
                + " JOIN users AS up ON up.uid = dates.proposer" + " JOIN users AS ui ON ui.uid = user_date.uid"
                + " WHERE dates.did = ? AND ui.username = ?");
        pst.setInt(1, dateId);
        pst.setString(2, username);
        ResultSet result = pst.executeQuery();
        result.next();
        Date resultDate = new Date(result.getInt("did"), result.getString("proposer"), result.getString("date_name"),
                new ArrayList<Event>(), "", new ArrayList<String>());
        switch (result.getInt("status")) {
            case 0:
                resultDate.setStatus("ongoing");
                break;
            case 1:
                resultDate.setStatus("accepted");
                break;
            case 2:
                resultDate.setStatus("rejected");
                break;
        }
        resultDate.setEvents(getEventsOfDate(conn, dateId, userId));
        resultDate.setInvitees(getInviteesOfDate(conn, dateId));
        return resultDate;
    }

    int getUserOfDate(Connection conn, int dateId, String username) throws SQLException, UnauthorizedException {
        PreparedStatement pst = conn.prepareStatement("SELECT users.uid FROM users"
                + " JOIN user_date ON user_date.uid = users.uid" + " WHERE username = ? AND user_date.did = ?");
        pst.setString(1, username);
        pst.setInt(2, dateId);
        ResultSet result = pst.executeQuery();
        if (result.next()) {
            return result.getInt("uid");
        } else {
            throw new UnauthorizedException();
        }
    }

    List<Event> getEventsOfDate(Connection conn, int dateId, int userId) throws SQLException {
        PreparedStatement pst = conn.prepareStatement("SELECT date_event.eid, tmid, preference, available"
                + " FROM dates JOIN date_event ON date_event.did = dates.did"
                + " JOIN events ON events.eid = date_event.eid" + " JOIN user_event ON user_event.eid = events.eid"
                + " WHERE dates.did = ? AND uid = ?");
        pst.setInt(1, dateId);
        pst.setInt(2, userId);
        ResultSet result = pst.executeQuery();
        ArrayList<Event> resultEvents = new ArrayList<Event>();
        while (result.next()) {
            resultEvents.add(new Event(result.getInt("eid"), result.getString("tmid"), result.getInt("preference"),
                    result.getInt("available")));
        }
        return resultEvents;
    }

    List<String> getInviteesOfDate(Connection conn, int dateId) throws SQLException {
        PreparedStatement pst = conn.prepareStatement(
                "SELECT username FROM dates JOIN user_date ON user_date.did = dates.did JOIN users ON users.uid = user_date.uid WHERE dates.did = ?");
        pst.setInt(1, dateId);
        ResultSet result = pst.executeQuery();
        ArrayList<String> resultInvitees = new ArrayList<String>();
        while (result.next()) {
            resultInvitees.add(result.getString("username"));
        }
        return resultInvitees;
    }

    List<Date> getProposed(Connection conn, String username) throws SQLException, UnauthorizedException {
        ArrayList<Date> resultEvents = new ArrayList<csci310.model.Date>();
        PreparedStatement pst = conn.prepareStatement(
                "SELECT did FROM dates JOIN users ON dates.proposer = users.uid WHERE username = ? AND final_event IS NULL");
        pst.setString(1, username);
        ResultSet result = pst.executeQuery();
        while (result.next()) {
            resultEvents.add(getDate(conn, result.getInt("did"), username));
        }
        return resultEvents;
    }

    List<Date> getInvited(Connection conn, String username) throws SQLException, UnauthorizedException {
        ArrayList<Date> resultEvents = new ArrayList<Date>();
        PreparedStatement pst = conn.prepareStatement("SELECT dates.did FROM dates"
                + " JOIN user_date ON user_date.did = dates.did" + " JOIN users ON user_date.uid = users.uid"
                + " WHERE username = ? AND users.uid != dates.proposer");
        pst.setString(1, username);
        ResultSet result = pst.executeQuery();
        while (result.next()) {
            resultEvents.add(getDate(conn, result.getInt("did"), username));
        }
        return resultEvents;
    }

    List<Date> getFinalized(Connection conn, String username) throws SQLException, UnauthorizedException {
        ArrayList<Date> resultEvents = new ArrayList<csci310.model.Date>();
        PreparedStatement pst = conn.prepareStatement("SELECT dates.did FROM dates"
                + " JOIN user_date ON user_date.did = dates.did" + " JOIN users ON user_date.uid = users.uid"
                + " WHERE username = ? AND final_event IS NOT NULL");
        pst.setString(1, username);
        ResultSet result = pst.executeQuery();
        while (result.next()) {
            resultEvents.add(getDate(conn, result.getInt("did"), username));
        }
        return resultEvents;
    }

    boolean setPreference(Connection conn, String username, int eid, int preference) throws SQLException {
        PreparedStatement pst = conn.prepareStatement("UPDATE user_event" + " SET preference=?" + " FROM users"
                + " WHERE users.uid = user_event.uid AND username=? AND eid=?" + " RETURNING eid");
        pst.setInt(1, preference);
        pst.setString(2, username);
        pst.setInt(3, eid);
        ResultSet result = pst.executeQuery();
        return result.next();
    }

    boolean setAvailable(Connection conn, String username, int eid, boolean available) throws SQLException {
        PreparedStatement pst = conn.prepareStatement("UPDATE user_event" + " SET available=?" + " FROM users"
                + " WHERE users.uid = user_event.uid AND username=? AND eid=?" + " RETURNING eid");
        if (available) {
            pst.setInt(1, 1);
        } else {
            pst.setInt(1, 0);
        }
        pst.setString(2, username);
        pst.setInt(3, eid);
        ResultSet result = pst.executeQuery();
        return result.next();
    }

    List<Event> finalize(Connection conn, int did, String username) throws SQLException, UnauthorizedException {
        // Verify date belongs to user
        PreparedStatement pst = conn
                .prepareStatement("SELECT did FROM dates JOIN users ON proposer = uid WHERE username = ? AND did = ?");
        pst.setString(1, username);
        pst.setInt(2, did);
        ResultSet result = pst.executeQuery();
        if (!result.next()) {
            throw new UnauthorizedException();
        }
        List<Event> resultEvents = new ArrayList<Event>();
        // Aim for highest preference
        pst = conn.prepareStatement("SELECT date_event.eid, SUM(preference) AS total_preference FROM dates"
                + " JOIN date_event ON date_event.did = dates.did" + " JOIN user_date ON user_date.did = dates.did"
                + " JOIN user_event ON user_event.uid = user_date.uid AND user_event.eid = date_event.eid"
                + " WHERE dates.did = ? AND preference > 0 AND available = 1" + " GROUP BY date_event.eid"
                + " ORDER BY total_preference DESC, RANDOM () LIMIT 1");
        pst.setInt(1, did);
        result = pst.executeQuery();
        while (result.next()) {
            resultEvents.add(new Event(result.getInt("eid"), "", -1, -1));
        }
        if (resultEvents.size() > 0) {
            return resultEvents;
        }
        // Nobody responded, select by random
        pst = conn.prepareStatement("SELECT eid FROM date_event WHERE did = ? ORDER BY RANDOM ()");
        pst.setInt(1, did);
        result = pst.executeQuery();
        while (result.next()) {
            resultEvents.add(new Event(result.getInt("eid"), "", -1, -1));
        }
        return resultEvents;
    }

    boolean setFinalized(Connection conn, int did, int eid, String username) throws SQLException {
        PreparedStatement pst = conn.prepareStatement("UPDATE dates SET final_event = ?"
                + " FROM user_date, users"
                + " WHERE dates.did = ? AND username = ?"
                + " AND dates.did = user_date.did AND user_date.uid = users.uid" + " RETURNING dates.did");
        pst.setInt(1, eid);
        pst.setInt(2, did);
        pst.setString(3, username);
        ResultSet result = pst.executeQuery();
        return result.next();
    }

    boolean accept(Connection conn, int did, String username) throws SQLException {
        PreparedStatement pst = conn.prepareStatement("UPDATE user_date SET status = 1" + " FROM dates, users"
                + " WHERE users.uid = user_date.uid AND username = ?"
                + " AND dates.did = user_date.did AND user_date.did = ? AND final_event IS NOT NULL"
                + " RETURNING user_date.did");
        pst.setString(1, username);
        pst.setInt(2, did);
        ResultSet result = pst.executeQuery();
        return result.next();
    }

    boolean decline(Connection conn, int did, String username) throws SQLException {
        PreparedStatement pst = conn.prepareStatement("UPDATE user_date SET status = 2" + " FROM dates, users"
                + " WHERE users.uid = user_date.uid AND username = ?"
                + " AND dates.did = user_date.did AND user_date.did = ? AND final_event IS NOT NULL"
                + " RETURNING user_date.did");
        pst.setString(1, username);
        pst.setInt(2, did);
        ResultSet result = pst.executeQuery();
        return result.next();
    }

    boolean deleteDate(Connection conn, int did, String username) throws SQLException {
        // Delete events
        PreparedStatement pst = conn.prepareStatement(
                "DELETE FROM events" + " USING date_event, users, dates"
                        + " WHERE date_event.eid = events.eid AND date_event.did = dates.did AND users.uid = dates.proposer"
                        + " AND date_event.did = ? AND username = ?" + " RETURNING events.eid");
        pst.setInt(1, did);
        pst.setString(2, username);
        ResultSet result = pst.executeQuery();
        if (!result.next()) {
            return false;
        }
        // Delete date_event
        pst = conn.prepareStatement("DELETE FROM date_event WHERE did=?");
        pst.setInt(1, did);
        pst.executeUpdate();
        // Delete user_date
        pst = conn.prepareStatement("DELETE FROM user_date WHERE did=?");
        pst.setInt(1, did);
        pst.executeUpdate();
        // Delete date
        pst = conn.prepareStatement("DELETE FROM dates WHERE did=?");
        pst.setInt(1, did);
        pst.executeUpdate();
        return true;
    }

    boolean deleteInvitee(Connection conn, int did, String toDelete, String username) throws SQLException {
        PreparedStatement pst = conn.prepareStatement(
                "DELETE FROM user_date USING users AS ud, users AS up, dates" + " WHERE user_date.did=?"
                        + " AND user_date.uid=ud.uid AND ud.username=?"
                        + " AND user_date.did=dates.did AND dates.proposer=up.uid AND up.username?"
                        + " RETURNING user_date.uid");
        pst.setInt(1, did);
        pst.setString(2, toDelete);
        pst.setString(3, username);
        ResultSet result = pst.executeQuery();
        return result.next();
    }

    boolean deleteEvent(Connection conn, int did, int eid, String username) throws SQLException {
        PreparedStatement pst = conn.prepareStatement("DELETE FROM events WHERE eid=?");
        pst.executeUpdate();
        pst = conn.prepareStatement("DELETE FROM date_event WHERE did=? AND eid=? RETURNING eid");
        ResultSet result = pst.executeQuery();
        return result.next();
    }

}
