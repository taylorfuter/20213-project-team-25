package csci310.date;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import csci310.GroupDateApp;
import csci310.common.AuthenticateJwt;
import csci310.exception.DateCreationException;
import csci310.exception.DateNotFoundException;
import csci310.exception.EventNotFoundException;
import csci310.exception.InvalidPreferenceException;
import csci310.exception.NoNameSpecifiedException;
import csci310.exception.SelfInvitedException;
import csci310.exception.UnauthorizedException;
import csci310.exception.UserNotFoundException;
import csci310.model.Date;
import csci310.model.Event;
import csci310.model.ProposedDate;

@RestController
@RequestMapping(value = "/api/date")
@CrossOrigin()
public class DateController {

    DateDatabase dbUtils = new DateDatabase();

    @PostMapping("/propose")
    public Date proposeRoute(@RequestHeader(value = "Authorization", required = true) String token,
            @RequestBody ProposedDate proposedDate) throws SQLException, DateCreationException, IOException,
            UnauthorizedException, SelfInvitedException, NoNameSpecifiedException {
        String username = AuthenticateJwt.authenticate(token);
        int dateId = dbUtils.createDate(GroupDateApp.conn, proposedDate.name, username, proposedDate.events,
                proposedDate.invitees);
        return dbUtils.getDate(GroupDateApp.conn, dateId, username);
    }

    @GetMapping("/proposed")
    public List<Date> proposedRoute(@RequestHeader(value = "Authorization", required = true) String token)
            throws SQLException, IOException, UnauthorizedException {
        String username = AuthenticateJwt.authenticate(token);
        return dbUtils.getProposed(GroupDateApp.conn, username);
    }

    @GetMapping("/finalized")
    public List<Date> finalizedRoute(@RequestHeader(value = "Authorization", required = true) String token)
            throws SQLException, IOException, UnauthorizedException {
        String username = AuthenticateJwt.authenticate(token);
        return dbUtils.getFinalized(GroupDateApp.conn, username);
    }

    @GetMapping("/invited")
    public List<Date> invitedRoute(@RequestHeader(value = "Authorization", required = true) String token)
            throws SQLException, IOException, UnauthorizedException {
        String username = AuthenticateJwt.authenticate(token);
        return dbUtils.getInvited(GroupDateApp.conn, username);
    }

    @PostMapping("/preference")
    public void preferenceRoute(@RequestHeader(value = "Authorization", required = true) String token,
            @RequestParam("eid") int eid, @RequestParam("preference") int preference) throws EventNotFoundException,
            InvalidPreferenceException, UnauthorizedException, IOException, SQLException {
        String username = AuthenticateJwt.authenticate(token);
        if (preference < 1 || preference > 5) {
            throw new InvalidPreferenceException();
        }
        if (!dbUtils.setPreference(GroupDateApp.conn, username, eid, preference)) {
            throw new EventNotFoundException();
        }
    }

    @PostMapping("/available")
    public void availableRoute(@RequestHeader(value = "Authorization", required = true) String token,
            @RequestParam("eid") int eid, @RequestParam("available") boolean available) throws EventNotFoundException,
            InvalidPreferenceException, UnauthorizedException, IOException, SQLException {
        String username = AuthenticateJwt.authenticate(token);
        if (!dbUtils.setAvailable(GroupDateApp.conn, username, eid, available)) {
            throw new EventNotFoundException();
        }
    }

    @PostMapping("/finalize")
    public List<Event> finalizeRoute(@RequestHeader(value = "Authorization", required = true) String token,
            @RequestParam("did") int did) throws UnauthorizedException, IOException, SQLException {
        String username = AuthenticateJwt.authenticate(token);
        return dbUtils.finalize(GroupDateApp.conn, did, username);
    }

    @PostMapping("/accept")
    public void acceptRoute(@RequestHeader(value = "Authorization", required = true) String token,
            @RequestParam("did") int did)
            throws UnauthorizedException, IOException, SQLException, DateNotFoundException {
        String username = AuthenticateJwt.authenticate(token);
        if (!dbUtils.accept(GroupDateApp.conn, did, username)) {
            throw new DateNotFoundException();
        }
    }

    @PostMapping("/decline")
    public void declineRoute(@RequestHeader(value = "Authorization", required = true) String token,
            @RequestParam("did") int did)
            throws UnauthorizedException, IOException, SQLException, DateNotFoundException {
        String username = AuthenticateJwt.authenticate(token);
        if (!dbUtils.decline(GroupDateApp.conn, did, username)) {
            throw new DateNotFoundException();
        }
    }

    @PostMapping("/select_final")
    public void selectFinalRoute(@RequestHeader(value = "Authorization", required = true) String token,
            @RequestParam("did") int did, @RequestParam("eid") int eid)
            throws SQLException, IOException, UnauthorizedException, DateNotFoundException {
        String username = AuthenticateJwt.authenticate(token);
        if (!dbUtils.setFinalized(GroupDateApp.conn, did, eid, username)) {
            throw new DateNotFoundException();
        }
    }

    @DeleteMapping("/")
    public void deleteDateRoute(@RequestHeader(value = "Authorization", required = true) String token,
            @RequestParam("did") int did)
            throws UnauthorizedException, IOException, SQLException, DateNotFoundException {
        String username = AuthenticateJwt.authenticate(token);
        if (!dbUtils.deleteDate(GroupDateApp.conn, did, username)) {
            throw new DateNotFoundException();
        }
    }

    @DeleteMapping("/event")
    public void deleteEventRoute(@RequestHeader(value = "Authorization", required = true) String token,
            @RequestParam("did") int did, @RequestParam("eid") int eid)
            throws UnauthorizedException, IOException, SQLException, EventNotFoundException {
        String username = AuthenticateJwt.authenticate(token);
        if (!dbUtils.deleteEvent(GroupDateApp.conn, did, eid, username)) {
            throw new EventNotFoundException();
        }
    }

    @DeleteMapping("/invitee")
    public void deleteInviteeRoute(@RequestHeader(value = "Authorization", required = true) String token,
            @RequestParam("did") int did, @RequestParam("to_delete") String toDelete)
            throws UnauthorizedException, IOException, SQLException, UserNotFoundException {
        String username = AuthenticateJwt.authenticate(token);
        if (!dbUtils.deleteInvitee(GroupDateApp.conn, did, toDelete, username)) {
            throw new UserNotFoundException();
        }
    }

}
