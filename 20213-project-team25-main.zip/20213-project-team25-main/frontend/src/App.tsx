import React from "react";
import './App.css';
import {GroupMeetRouter} from "./router/GroupMeetRouter";
import 'bootstrap/dist/css/bootstrap.min.css';
import {AuthProvider} from "react-auth-kit";


function App() {
  return (
      <AuthProvider
          authType="cookie"
          authName="_auth"
          cookieDomain={window.location.hostname}
          cookieSecure={window.location.protocol === "https:"}
          >
          <GroupMeetRouter/>
      </AuthProvider>
  );
}

export default App;
