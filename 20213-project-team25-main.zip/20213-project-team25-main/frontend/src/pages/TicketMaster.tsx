import "./TicketMasterStyle.css";
import * as React from "react";
import {useCallback, useEffect, useState} from "react";
import {AutoComplete, Button, DatePicker, Form, Input, message, Modal, Table} from "antd";
import {MinusCircleOutlined, PlusOutlined, SearchOutlined} from '@ant-design/icons';
import {useAuthUser} from "react-auth-kit";
import {useForm} from "antd/es/form/Form";
import {ROOT_URI} from "../config";
import {JSON_HEADER} from "../constants";
import moment from 'moment';

const { RangePicker } = DatePicker;

export const TicketMaster: React.FC = () => {
    const position_query = "https://app.ticketmaster.com/discovery/v2/events.json";

    // get from ticket master api
    // used as table rows
    const [events, setEvents] = useState<Array<Object>>([]);
    // user select rows, each is one event from events
    const [selectedEvents, setSelectedEvents] = useState<Array<Object>>([]);
    const [totalEvents, setTotalEvents] = useState<Array<Object>>([]);


    const auth = useAuthUser();
    const user = auth()!;

    const autofill = (searchText: string) => {
        console.log("searching for ", searchText);
        fetch(`${ROOT_URI}/user/autofill?username=${searchText}`, {
            headers: {
                ...JSON_HEADER,
                'Authorization': user.token,
            },
            method: "get",
        })
        .then((resp: any) => resp.json())
        .then(resp => {
            setOptions(resp.map((name: string) => ({
                value: name
            })));
        })
    }

    // in autocomplete
    const [options, setOptions] = useState<{ value: string }[]>([]);
    const onSearch = (searchText: string) => {
        if (!searchText) setOptions([]);
        else
            autofill(searchText);
    };

    const divStyle = {
        height:'200px',
        width:'200px',
    };

    function disabledDate(current:any) {
        // Can not select days before today and today
        return current < moment().add(-1, 'days').endOf('day');
    }

        // @ts-ignore
    const columns = [
        {
            title: 'Image',
            dataIndex: ["images","0", "url"],
            render:  (text:string, record:any) =>
                <a href={record.url} target={"_blank"} rel="noreferrer">
                    <img src={record.images[0].url} style={divStyle} alt={record.name}/>
                </a>
        },
        {
            title: 'Date',
            dataIndex: ['dates', 'start','localDate'],
            key: 'localDate',
            sorter: (a:any,b:any) => a.dates.start.localDate.localeCompare(b.dates.start.localDate),
            filterDropdown: () => {
                return <RangePicker
                    autoFocus
                    disabledDate = {disabledDate}
                    onChange={(e:any)=> {
                        setEvents(totalEvents.filter((event: any)=> (e === undefined ? false : (e === null) ? true: event.dates.start.localDate >= e[0].format("YYYY-MM-DD") && event.dates.start.localDate <= e[1].format("YYYY-MM-DD"))));
                    }}
                />
            },
        },
        {
            title: 'Name',
            dataIndex: 'name',
            key: 'name',
            sorter: (a:any,b:any) => a.name.localeCompare(b.name),
            filterDropdown: () => {
                 return <Input
                        autoFocus
                        placeholder="Keyword"
                        onPressEnter={(e) => {
                            setEvents(totalEvents.filter((event: any)=> event.name.toLowerCase().includes((e.target as HTMLInputElement).value.toLowerCase())));
                        }}
                        onBlur={(e) => {
                            setEvents(totalEvents.filter((event: any)=> event.name.toLowerCase().includes((e.target as HTMLInputElement).value.toLowerCase())));
                        }}
                        className="groupie-keyword-input"
                    />
            },
            filterIcon: () => {
                return <SearchOutlined />;
            },
            onFilter: (value:any,record:any)=>{
                return record.name.toLowerCase().includes(value.toLowerCase())
            },
        },
        {
            title: 'Location',
            dataIndex: ['_embedded', 'venues', '0', 'city', 'name'],
            key: 'location',
            filterDropdown: () => {
                return <Input
                    autoFocus
                    placeholder="City name"
                    onPressEnter={(e) => {
                        setEvents(totalEvents.filter((event: any)=> ( event._embedded === undefined ? (event.place === undefined ? false: event.place.city.name.toLowerCase().includes((e.target as HTMLInputElement).value.toLowerCase())  ): event._embedded.venues[0].city.name.toLowerCase().includes((e.target as HTMLInputElement).value.toLowerCase()))));
                    }}
                    onBlur={(e) => {
                        setEvents(totalEvents.filter((event: any)=> ( event._embedded === undefined ? (event.place === undefined ? false: event.place.city.name.toLowerCase().includes((e.target as HTMLInputElement).value.toLowerCase())  ): event._embedded.venues[0].city.name.toLowerCase().includes((e.target as HTMLInputElement).value.toLowerCase()))));
                    }}
                    className="groupie-location-filter-input"
                />
            },
            filterIcon: () => {
                return <SearchOutlined />;
            },
            onFilter: (value:any,record:any)=>{
                return record.name.toLowerCase().includes(value.toLowerCase())
            },
            render: (info: string, record:any) => (
                (record._embedded === undefined ? (record.place === undefined ? "Unknown location" : (record.place.state === undefined ? record.place.city.name + ", " + record.place.country.name: record.place.city.name + ", " + record.place.state.name)) : (record._embedded.venues[0].state === undefined ? record._embedded.venues[0].city.name + ", "+ record._embedded.venues[0].country.name : record._embedded.venues[0].city.name + ", "+ record._embedded.venues[0].state.name)
            ))
        },
        {
            title: 'Genre',
            dataIndex: ['classifications','0', 'segment', 'name'],
            key: 'genre',
            render: (genre: string) => (
                (genre === undefined ? "Undefined" : genre)
            ),
            filters: [
                {
                    text: 'Film',
                    value: "Film",
                },
                {
                    text: 'Music',
                    value: 'Music',
                },
                {
                    text: 'Sports',
                    value: "Sports",
                },
                {
                    text: 'Arts & Theatre',
                    value: 'Arts & Theatre',
                },
                {
                    text: 'Family',
                    value: "Family",
                },
                {
                    text: 'Miscellaneous',
                    value: 'Miscellaneous',
                },
            ],
            onFilter: (value:any, record:any) => (
                (record.classifications === undefined ? false : record.classifications[0].segment.name.indexOf(value) === 0)
            ),
        },
        {
            title: 'Description',
            dataIndex: 'info',
            key: 'info',
            render: (info: string) => (
                (info === undefined ? "This event doesn't have a description." : info)
            )
        },
    ];

    const rowSelection = {
        onChange: (selectedRowKeys: React.Key[], selectedRows: Object[]) => {
            console.log( 'selectedRows: ', selectedRows);
            // @ts-ignore
            setSelectedEvents(selectedRows);
        },
    };


    /**
     * given latlong, provide nearby events using API
     * @param latitude
     * @param longitude
     */
    const fetchPosition = useCallback((
        {latitude, longitude} : {latitude: number, longitude: number}
    ) => {
        const latLong = latitude + "," + longitude;
        console.log(latLong);
        const defaultSort = 'date,asc';
        const defaultSize = '200';
        const page = '0';
        const startDate = new Date().toLocaleString("sv-SE").replaceAll(" ", "T") + "Z";
        fetch(`${position_query}?apikey=${process.env.REACT_APP_TICKETMASTER_API_KEY}&sort=${defaultSort}&size=${defaultSize}&page=${page}&startDateTime=${startDate}`)
            .then(res => res.json())
            .then(res => {
                console.log(res);
                setEvents(res._embedded.events);
                setTotalEvents(res._embedded.events);
            })
            .catch(err => console.error(err))
    }, [])
    useEffect(() => {
        navigator.geolocation.getCurrentPosition(
            (pos) => {
                // console.log(pos);
                fetchPosition({
                    latitude: pos.coords.latitude,
                    longitude: pos.coords.longitude});
            },
            (err) => {
                console.error(err);
                // alert("please enable geolocation");
            }
        )
    }, [fetchPosition])

    const [isModalVisible, setIsModalVisible] = useState(false);

    const [form] = useForm();

    const handleOk = () => {
        setIsModalVisible(false);
        const invitees: Array<string> = form.getFieldsValue().names
        // @ts-ignore
        let event_ids: Array<string> = selectedEvents.map(e => e.id);
        console.log(event_ids);
        let to_send = {
            "name": form.getFieldsValue().event,
            "events": event_ids,
            "invitees": invitees
        }
        console.log(to_send);
        fetch(
            `${ROOT_URI}/date/propose`,{
                headers: {
                    ...JSON_HEADER,
                    'Authorization': user.token,
                },
                body: JSON.stringify(to_send),
                method: "POST"
            }
        ).then(res => res.json())
            .then(res => {
                // message.info(res);
                if (res.error){
                    message.error(res.error);
                }
                else{
                    message.success("done!")
                }
            })
            .catch(error => console.error(error))
        form.resetFields();
    };

    const formItemLayout = {
        labelCol: {
            xs: { span: 26},
            sm: { span: 6},
        },
        wrapperCol: {
            xs: { span: 24 },
            sm: { span: 20},
        },
    };
    const formItemLayoutWithOutLabel = {
        wrapperCol: {
            xs: { span: 24, offset: 2 },
            sm: { span: 20, offset: 6 },
        },
    };


    return (
        <div id="ticket-master-page-content">
            <div id="ticket-master-table">
                <Button className="inviteFriendsButton"
                        disabled={selectedEvents.length === 0}
                        onClick={() => setIsModalVisible(true)}>
                    Invite Friends
                </Button>
                <Table
                    rowSelection={{
                        type: 'checkbox',
                        ...rowSelection,
                    }}
                    dataSource={events}
                    rowKey="id"
                    columns={columns} />

            </div>
            <Modal title="Invite Friends" visible={isModalVisible} onOk={handleOk} onCancel={() => setIsModalVisible(false)}>
                <Form
                    form={form}
                    name="dynamic_form_item"
                    initialValues={{ names: [''] }}
                    {...formItemLayoutWithOutLabel}>
                    <Form.Item name="event" label="Group Date Name:" {...formItemLayout}>
                        <Input placeholder="Winter Break Plans" style={{ width: '60%' }} className="groupie-date-name-input"/>
                    </Form.Item>
                    <Form.List
                        name="names"
                    >
                        {(fields, { add, remove }, { errors }) => (
                            <>
                                {fields.map((field, index) => (
                                    <Form.Item
                                        {...(index === 0 ? formItemLayout : formItemLayoutWithOutLabel)}
                                        label={index === 0 ? 'Invitees' : ''}
                                        required={false}
                                        key={field.key}
                                    >
                                        <Form.Item
                                            {...field}
                                            validateTrigger={['onChange', 'onBlur']}
                                            rules={[
                                                {
                                                    required: true,
                                                    whitespace: true,
                                                    message: "Please input friend's username or delete this field.",
                                                },
                                            ]}
                                            noStyle
                                        >
                                            <AutoComplete
                                                options={options}
                                                onSearch={onSearch}
                                                placeholder="Friend's username"
                                                className="groupie-invitee-input"
                                                />
                                        </Form.Item>
                                        {fields.length > 1 ? (
                                            <MinusCircleOutlined
                                                className="dynamic-delete-button"
                                                onClick={() => remove(field.name)}
                                            />
                                        ) : null}
                                    </Form.Item>
                                ))}
                                <Form.Item>
                                    <Button
                                        type="dashed"
                                        onClick={() => add()}
                                        style={{ width: '60%' }}
                                        icon={<PlusOutlined />}
                                        className="groupie-another-friend"
                                    >
                                        Invite another friend
                                    </Button>
                                    <Form.ErrorList errors={errors} />
                                </Form.Item>
                            </>
                        )}
                    </Form.List>
                </Form>
            </Modal>
        </div>
    )
}
