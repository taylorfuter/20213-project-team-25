import {useAuthUser} from "react-auth-kit";
import {AuthStateUserObject} from "react-auth-kit/dist/types";
import React, {useEffect, useState} from "react";
import {ROOT_URI} from "../config";
import {JSON_HEADER} from "../constants";
import {Container} from "react-bootstrap";
import {Spin} from "antd";
import './ViewInvitations.css';
import {UserSettingsContent} from "./UserSettingsContent";

export const UserSettings = () => {
    const auth = useAuthUser();
    const user: AuthStateUserObject = auth()!;

    const [users, setUsers] = useState<Array<String>>([])
    const [fetchDone, setFetchDone] = useState<boolean>(false);


    useEffect(() => {
        fetch(`${ROOT_URI}/user/blocked?username=`, {
                    headers: {
                        ...JSON_HEADER,
                        'Authorization': user.token,
                    },
                    method: "get",
                })
            .then(res1 => res1.json())
            .then(res1 => {
                setFetchDone(true);
                setUsers(res1);
            })
            .catch(err => console.error(err))
    }, [users, user.token] )

    if (!fetchDone){
        return <Spin size="large" style={{ height: "50%", marginLeft: "50vw" }}/>
    }

    return (
        <Container style={{
            backgroundColor: "white"
        }}>
            <UserSettingsContent users={users}/>
        </Container>
    )

}
