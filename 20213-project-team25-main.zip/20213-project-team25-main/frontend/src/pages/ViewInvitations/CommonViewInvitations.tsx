import {Breadcrumb, Typography} from "antd";
import {CalendarOutlined, HomeOutlined} from "@ant-design/icons";
import React from "react";

const { Text} = Typography;

export const bc = (
    <Breadcrumb
        className="view-invitations-breadcrumb"
    >
        <Breadcrumb.Item href="/main">
            <HomeOutlined />
        </Breadcrumb.Item>
        <Breadcrumb.Item>
            <CalendarOutlined /> <Text>View Invitations</Text>
        </Breadcrumb.Item>
    </Breadcrumb>
)