import {Avatar, Col, PageHeader, Rate, Row, Select, Space, Statistic, Table, Tag, Tooltip, Typography,} from "antd";
import {CheckSquareTwoTone, ClockCircleTwoTone} from "@ant-design/icons";
import React, {useEffect, useState} from "react";
import {ProposedDate, ProposedEvent} from "../../types/Interfaces";
import {ROOT_URI} from "../../config";
import {useAuthUser} from "react-auth-kit";
import {AuthStateUserObject} from "react-auth-kit/dist/types";
import {bc} from "./CommonViewInvitations";

const { Paragraph } = Typography;
const { Link, Text } = Typography;
const { Option } = Select;

/**
 * The actual page header content and table
 * the dates is guaranteed not empty
 */
const InvitationsContent: React.FC<{dates: Array<ProposedDate> }> = ({dates}) => {
    const auth = useAuthUser();
    const user: AuthStateUserObject = auth()!;

    const [currentDate, setCurrentDate] = useState<ProposedDate>(dates[0]);
    const [eventsInTable, setEventsInTable] = useState<Array<Object>>([]);

    const AvailableWidget: React.FC<{event: ProposedEvent}> = ({event}) => {
        const [available, setAvailable] = useState<null | boolean>(null);
        const set_availability = (yes_or_no: boolean) => {
            fetch(`${ROOT_URI}/date/available?eid=${event.id}&available=${yes_or_no}`, {
                headers: {
                    'Authorization': user.token,
                },
                method: "post"
            })
                .then(() => setAvailable(yes_or_no))
        }

        if (available === true || event.available === 1)
            return (
                <div>
                    <Text>You accepted </Text>
                    <Link type="danger" onClick={() => set_availability(false)}>Change your mind?</Link>
                </div>
            )
        else if (available === false || event.available === 0)
            return (
                <div>
                    <Text>You declined </Text>
                    <Link type="danger" onClick={() => set_availability(true)}>Change your mind?</Link>
                </div>
            )

        return (
            <Space size="middle">
                <Link type="success" onClick={() => set_availability(true)}>Accept</Link>
                <Link type="danger" onClick={() => set_availability(false)}>Refuse</Link>
            </Space>
        )

    }

    useEffect(() => {
        const calls = currentDate.events.map(e =>
            `https://app.ticketmaster.com/discovery/v2/events/${e.tmid}.json?apikey=${process.env.REACT_APP_TICKETMASTER_API_KEY}`)
            .map(url => fetch(url, {method: "get"}))
        Promise.all(calls)
            .then(resps => Promise.all(resps.map(resp => resp.json())))
            .then((events: Array<Object>) => {
                events = events.map((e, i) => ({
                    ...e,
                    ...currentDate.events[i],
                }));
                console.log(events);
                setEventsInTable(events);
            })
    }, [currentDate]);

    const columns = [
        {
            title: 'Name',
            dataIndex: "name",
            key: 'name'
        },
        {
            title: "Start",
            dataIndex: ["dates", "start", "localDate"],
        },
        {
            title: "Preference",
            dataIndex: "preference",
            render: (pref: number, row: any) => {
                const desc = ['I don\'t like this', 'slightly ok', 'fine', 'I\'m interested', 'I must go'];

                const onClickValue = (value: number) => {
                    console.log(value, row.id);
                    fetch(`${ROOT_URI}/date/preference?preference=${value}&eid=${row.id}`, {
                        headers: {
                            'Authorization': user.token,
                        },
                        method: "post"
                    });
                  }

                return <Rate tooltips={desc} onChange={onClickValue} defaultValue={pref === -1 ? 0 : pref}/>
            }
        },
        {
            title: 'Action',
            key: 'action',
            render: (event: ProposedEvent) => {
                return <AvailableWidget event={event}/>
            }
        },
    ];


    function select_date(selected: string){
        console.log(`select index ${selected}`);
        setCurrentDate(dates[parseInt(selected)]);
    }

    return (
        <Space
            style={{ width: "100%" }}
            direction="vertical" size="large">
            <Row className="view-invitation-statics">
                <Statistic
                    title="Pending"
                    prefix={<ClockCircleTwoTone />}
                    value={0}
                />
                <Statistic
                    title="Accepted"
                    prefix={<CheckSquareTwoTone />}
                    value={0}
                    style={{
                        margin: '0 32px',
                    }}
                />
                <Statistic
                    title="Total"
                    prefix="#"
                    value={
                        `${dates.map(date => 
                            date.events.length).reduce(
                                (a, b) => a+b, 0)} events`
                    }
                />
            </Row>
            <Row>
                <Col>
                    <Select
                        defaultValue={currentDate.name}
                        onSelect={select_date}
                    >
                        {dates.map((date, i) => (
                            <Option key={i} value={i}>
                                {date.name}
                            </Option>
                        ))}
                    </Select>
                </Col>
                <Col offset={3}>
                    <Avatar.Group>
                        {currentDate.invitees.map((user, i) => (
                            <Tooltip title={user} placement="top">
                                <Avatar size="large" key={i}>
                                    {user[0].toUpperCase()}
                                </Avatar>
                            </Tooltip>
                        ))}
                    </Avatar.Group>
                </Col>
                <Col flex="auto">
                    <div style={{ justifyContent: 'flex-end', display: "flex"}}>
                        <Tag color="cyan">{currentDate.status}</Tag>
                    </div>
                </Col>
            </Row>
            <Table
                rowKey="id"
                columns={columns}
                dataSource={eventsInTable}/>
        </Space>
    )

}

/**
 * Content of the view invitation page
 * Including a page header
 * the dates can be empty
 */
export const ViewInvitedInvitationsContent: React.FC<{
    dates: Array<ProposedDate>
}> = ({dates}) => {


    return (
        <PageHeader
            breadcrumb={bc}
            title="Your Invitations"
        >
            {(dates.length === 0) ? (
                <Paragraph>
                    You do not have any invitations so far.
                </Paragraph>
            ) : <InvitationsContent dates={dates} />}
        </PageHeader>
    )
}
