import {useAuthUser} from "react-auth-kit";
import {AuthStateUserObject} from "react-auth-kit/dist/types";
import React, {useEffect, useState} from "react";
import {ROOT_URI} from "../../config";
import {JSON_HEADER} from "../../constants";
import {Container} from "react-bootstrap";
import {Spin} from "antd";
import '../ViewInvitations.css';
import {ProposedDate} from "../../types/Interfaces";
import {ViewProposeInvitationsContent} from "./ViewProposeInvitationsContent";

export const ViewProposedInvitations = () => {
    const auth = useAuthUser();
    const user: AuthStateUserObject = auth()!;

    const [dates, setDates] = useState<Array<ProposedDate>>([])
    const [fetchDone, setFetchDone] = useState<boolean>(false);

    useEffect(() => {
        fetch(`${ROOT_URI}/date/proposed`, {
            headers: {
                ...JSON_HEADER,
                'Authorization': user.token,
            },
            method: "get",
        })
        .then(resp => resp.json())
            .then(res => {
                setFetchDone(true);
                setDates(res)
            })
        .catch((err) => console.error(err))
    }, [user.token] );

    if (!fetchDone){
        return <Spin size="large" style={{ height: "50%", marginLeft: "50vw" }}/>
    }

    return (
        <Container style={{
            backgroundColor: "white"
        }}>
            <ViewProposeInvitationsContent dates={dates}/>
        </Container>
    )

}