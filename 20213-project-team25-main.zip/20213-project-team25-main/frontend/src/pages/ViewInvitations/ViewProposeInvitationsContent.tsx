import {Avatar, Col, PageHeader, Row, Select, Space, Statistic, Table, Tag, Tooltip, Typography,} from "antd";
import {CheckSquareTwoTone, ClockCircleTwoTone} from "@ant-design/icons";
import React, {useEffect, useState} from "react";
import {ProposedDate, ProposedEvent} from "../../types/Interfaces";
import {ROOT_URI} from "../../config";
import {useAuthUser} from "react-auth-kit";
import {AuthStateUserObject} from "react-auth-kit/dist/types";
import {bc} from "./CommonViewInvitations";

const { Paragraph } = Typography;
const { Link} = Typography;
const { Option } = Select;

/**
 * The actual page header content and table
 * the dates is guaranteed not empty
 */
const InvitationsContent: React.FC<{dates: Array<ProposedDate> }> = ({dates}) => {
    const auth = useAuthUser();
    const user: AuthStateUserObject = auth()!;

    const [currentDate, setCurrentDate] = useState<ProposedDate>(dates[0]);
    const [eventsInTable, setEventsInTable] = useState<Array<Object>>([]);
    useEffect(() => {
        const calls = currentDate.events.map(e =>
            `https://app.ticketmaster.com/discovery/v2/events/${e.tmid}.json?apikey=${process.env.REACT_APP_TICKETMASTER_API_KEY}`)
            .map(url => fetch(url, {method: "get"}))
        Promise.all(calls)
            .then(resps => Promise.all(resps.map(resp => resp.json())))
            .then((events: Array<Object>) => {
                events = events.map((e, i) => ({
                    ...e,
                    ...currentDate.events[i],
                }));
                console.log(events);
                setEventsInTable(events);
            })
    }, [currentDate]);

    const columns = [
        {
            title: 'Name',
            dataIndex: "name",
            key: 'name'
        },
        {
            title: "Start",
            dataIndex: ["dates", "start", "localDate"],
        },
        {
            title: 'Action',
            key: 'action',
            render: (event: ProposedEvent) => {
                const deleteEventFromDate = () => {
                    fetch(`${ROOT_URI}/date/event?did=${currentDate.id}&eid=${event.id}`, {
                        headers: {
                            'Authorization': user.token,
                        },
                        method: "delete"
                    });
                }
                return (
                    <Space size="middle">
                        {/* eslint-disable-next-line @typescript-eslint/no-unused-vars */}
                        <Link type="danger" onClick={deleteEventFromDate}>Delete</Link>
                    </Space>
                )
            }
        }
    ];


    function select_date(selected: string){
        setCurrentDate(dates[parseInt(selected)]);
    }

    return (
        <Space
            style={{ width: "100%" }}
            direction="vertical" size="large">
            <Row className="view-invitation-statics">
                <Statistic
                    title="Pending"
                    prefix={<ClockCircleTwoTone />}
                    value={0}
                />
                <Statistic
                    title="Accepted"
                    prefix={<CheckSquareTwoTone />}
                    value={0}
                    style={{
                        margin: '0 32px',
                    }}
                />
                <Statistic
                    title="Total"
                    prefix="#"
                    value={
                        `${dates.map(date =>
                            date.events.length).reduce(
                            (a, b) => a+b, 0)} events`
                    }
                />
            </Row>
            <Row>
                <Col>
                    <Select
                        defaultValue={currentDate.name}
                        onSelect={select_date}
                    >
                        {dates.map((date, i) => (
                            <Option key={i} value={i}>
                                {date.name}
                            </Option>
                        ))}
                    </Select>
                </Col>
                <Col offset={3}>
                    <Avatar.Group>
                        {currentDate.invitees.map((user, i) => (
                            <Tooltip title={user} placement="top">
                                <Avatar size="large" key={i}>
                                    {user[0].toUpperCase()}
                                </Avatar>
                            </Tooltip>
                        ))}
                    </Avatar.Group>
                </Col>
                <Col flex="auto">
                    <div style={{ justifyContent: 'flex-end', display: "flex"}}>
                        <Tag color="cyan">{currentDate.status}</Tag>
                    </div>
                </Col>
            </Row>
            <Table
                rowKey="id"
                columns={columns}
                dataSource={eventsInTable}/>
        </Space>
    )
}

/**
 * Content of the view invitation page
 * Including a page header
 * the dates can be empty
 */
export const ViewProposeInvitationsContent: React.FC<{dates: Array<ProposedDate> }> = ({dates}) => {

    return (
        <PageHeader
            breadcrumb={bc}
            title="Your Purposed Events"
        >
            {(dates.length === 0) ? (
                <Paragraph>
                    You do not have any invitations so far.
                </Paragraph>
            ) : <InvitationsContent dates={dates}/>}
        </PageHeader>
    )
}
