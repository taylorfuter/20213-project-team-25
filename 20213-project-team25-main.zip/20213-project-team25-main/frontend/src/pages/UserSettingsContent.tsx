import {Breadcrumb, Button, Form, Input, PageHeader, Space, Table, Typography,} from "antd";
import {CalendarOutlined, HomeOutlined} from "@ant-design/icons";
import {useForm} from "antd/es/form/Form";
import {ROOT_URI} from "../config";
import {useAuthUser} from "react-auth-kit";
import {AuthStateUserObject} from "react-auth-kit/dist/types";
import {useEffect, useState} from "react";

const { Paragraph } = Typography;
const { Text } = Typography;

/**
 * The actual page header content and table
 * the dates is guaranteed not empty
 */
const SettingsContent: React.FC<{users: Array<String> }> = ({users}) => {

    const auth = useAuthUser();
    const user: AuthStateUserObject = auth()!;

    const unblockUser = (name:string) => {
        fetch(
            `${ROOT_URI}/user/unblock?username=${name}`,{
                headers: {
                    'Authorization': user.token,
                },
                method: "POST"
            }
        )
            .catch(err => console.log(err))
    }

    const columns = [
        {
            title: 'Name',
            dataIndex: "name",
            key: 'name'
        },
        {
            title: '',
            key: 'action',
            render: (text:string, record:any) => (
                <Space size="middle">
                    <Button onClick={() => unblockUser(record.name)}>Unblock</Button>
                </Space>
            ),
        },
    ];

    const dataSource = users.map((str) => ({ name: str }));

    return (
        <Space
            style={{ width: "100%" }}
            direction="vertical" size="large">
            <Table
                rowKey="name"
                columns={columns}
                dataSource={dataSource}/>
        </Space>
    )

}

/**
 * Content of the view invitation page
 * Including a page header
 * the dates can be empty
 */
export const UserSettingsContent: React.FC<{users: Array<String> }> = ({users}) => {
    const bc = (
        <Breadcrumb
            className="view-invitations-breadcrumb"
        >
            <Breadcrumb.Item href="/main">
                <HomeOutlined />
            </Breadcrumb.Item>
            <Breadcrumb.Item>
                <CalendarOutlined /> <Text>View User Settings</Text>
            </Breadcrumb.Item>
        </Breadcrumb>
    )

    const [form] = useForm();

    const auth = useAuthUser();
    const user: AuthStateUserObject = auth()!;
    const [availability, setAvailability] = useState<String>()
    const [availableChange, setAvailableChange] = useState<boolean>(false);

    useEffect(() => {
       fetch(
           `${ROOT_URI}/user/info`,{
               headers: {
                   'Authorization': user.token,
               },
               method: "get"
           }
       )
           .then(res=>res.json())
           .then(res=> {
               if(res.available === false){
                   setAvailability("Unavailable");
               }
               else{
                   setAvailability("Available");
               }
           })
    },)
    const handleOk = () => {
        let to_send = form.getFieldsValue().event;
        fetch(
            `${ROOT_URI}/user/block?username=${to_send}`,{
                headers: {
                    'Authorization': user.token,
                },
                method: "POST"
            }
        )
            .catch(err => console.log(err))
        form.resetFields();
    }

    const changeAvailability = () => {
        setAvailableChange(!availableChange);
        let to_send = true;
        if (availability === "Available") {
            to_send = false;
        }
        fetch(
            `${ROOT_URI}/user/available?available=${to_send}`, {
                headers: {
                    'Authorization': user.token,
                },
                method: "POST"
            }
        )
            .catch(err => console.log(err))
    }

    const formItemLayout = {
        labelCol: {
            xs: { span: 26},
            sm: { span: 6},
        },
        wrapperCol: {
            xs: { span: 24 },
            sm: { span: 20},
        },
    };
    const formItemLayoutWithOutLabel = {
        wrapperCol: {
            xs: { span: 24, offset: 2 },
            sm: { span: 20, offset: 6 },
        },
    };

    return (
        <PageHeader
            breadcrumb={bc}
            title="Blocked Users"
        >
            {(users.length === 0) ? (
                <Paragraph>
                    You do not have any blocked users so far.
                </Paragraph>
            ) : <SettingsContent users={users}/>}
            <Form
                form={form}
                name="dynamic_form_item"
                initialValues={{ names: [''] }}
                {...formItemLayoutWithOutLabel}>
                    <Form.Item name="event" label="Block new user:" {...formItemLayout}>
                        <Input placeholder="username" style={{ width: '60%' }}/>
                    </Form.Item>
                    <Button onClick={handleOk} > Block</Button>
            </Form>
            <br/>
            <p>Your current availability is: {availability}</p>
            <Button onClick={changeAvailability} > Change Availability</Button>
            </PageHeader>
    )

}
