export interface ProposedEvent {
    id: number;
    tmid: string;
    preference: number;
    available: number;
}


export interface ProposedDate{
    id: number;
    proposer: string;
    name: string;
    events: Array<ProposedEvent>;
    status: string;
    invitees: Array<string>;
    final_event: number;
}