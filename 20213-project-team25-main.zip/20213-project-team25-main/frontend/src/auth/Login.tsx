import "./intro.css";
import {IntroContainer} from "./IntroContainer";
import {Button} from "react-bootstrap";
import {Button as AButton, Form, Input, message} from "antd";
import {LockOutlined, UserOutlined} from "@ant-design/icons";
import {ROOT_URI} from "../config";
import {useSignIn} from "react-auth-kit";
import {useHistory} from "react-router";
import {JSON_HEADER} from "../constants";
import {calc_expiration_in_min, onSubmitFailed} from "./AuthUtils";
import {useState} from "react";

const LoginForm = () => {
    const [form] = Form.useForm();
    const signIn = useSignIn();
    const history = useHistory();
    
    // if true, disable login button (when user tries too many times)
    const [login_btn_disabled, setLogin_btn_disabled] = useState<boolean>(false);

    const onSubmit = (values: any) => {
        fetch(`${ROOT_URI}/user/login`, {
            headers: JSON_HEADER,
            body: JSON.stringify(values),
            method: "post",
        })
            .then((resp: any) => {
                if (resp.status !== 200) {
                    if (resp.status === 401) {
                        message.error("username and password do not match");
                        return Promise.reject(resp);
                    } else if (resp.status === 429) {
                        message.error("Failed too many times");
                        setLogin_btn_disabled(true);
                        // 60 second
                        setTimeout(() => {
                            setLogin_btn_disabled(false)
                        }, 60000);
                        return Promise.reject(resp);
                    } else {
                        console.error("ERROR", resp);
                        return Promise.reject(resp);
                    }
                }
                else{
                    return resp.json();
                }
            })
            .then(resp => {
                console.log(resp);
                if(signIn({
                    token: resp.token,
                    expiresIn: calc_expiration_in_min(resp.validUntil),
                    tokenType: "jwt",
                    authState: {
                        username: values["username"],
                        token: `Bearer ${resp.token}`
                    },
                })){
                    console.log("suceess!", resp.token);
                    message.success(`Hello! ${values["username"]}!`);
                    history.push("/main");
                }
            })
            .catch((err: any) => console.error(err));
    }
    return (
        <Form
            form={form}
            name="login"
            onFinish={onSubmit}
            onFinishFailed={onSubmitFailed}
            scrollToFirstError
        >
            <Form.Item
                name="username"
                rules={[
                    {
                        required: true,
                        message: 'Please input your username!',
                    },
                ]}
            >
                <Input size="large" prefix={<UserOutlined/>} placeholder="username"/>
            </Form.Item>

            <Form.Item
                name="password"
                rules={[
                    {
                        required: true,
                        message: 'Please input your password!',
                    },
                ]}
                hasFeedback
            >
                <Input.Password size="large" prefix={<LockOutlined/>} placeholder="password" />
            </Form.Item>

            <div className="py-2"/>
            <Form.Item>
                <Button
                    disabled={login_btn_disabled}
                    variant="primary" className="btn-block"
                    type="submit"
                    style={{width: '100%'}}
                    size="lg">
                    Log In
                </Button>
            </Form.Item>
            <AButton type='primary' ghost href="/register">
                Don't have an account?
            </AButton>
        </Form>
    )
}
const Login = () => {

    return (
        <IntroContainer>
            <p className="signIn">Sign In</p>
            <LoginForm/>
        </IntroContainer>
    );
}

export default Login;

