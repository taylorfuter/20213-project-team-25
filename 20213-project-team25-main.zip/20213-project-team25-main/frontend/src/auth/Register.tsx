import "./intro.css";
import {IntroContainer} from "./IntroContainer";
import {Button} from "react-bootstrap";
import {Button as AButton, Form, Input, message} from "antd";
import {LockOutlined, UserOutlined} from "@ant-design/icons";
import {ROOT_URI} from "../config";
import {useSignIn} from "react-auth-kit";
import {useHistory} from "react-router";
import {JSON_HEADER} from "../constants";
import {calc_expiration_in_min, onSubmitFailed} from "./AuthUtils";

const RegisterForm = () => {
    const [form] = Form.useForm();
    const signIn = useSignIn();
    const history = useHistory();

    const onSubmit = (values: any) => {
        fetch(`${ROOT_URI}/user/signup`, {
                headers: JSON_HEADER,
                body: JSON.stringify(values),
                method: "post",
            })
            .then((resp: any) => {
                if (resp.status !== 200) {
                    if (resp.status === 409) {
                        message.error("username already taken");
                    } else {
                        console.error("ERROR", resp);
                        return Promise.reject(resp);
                    }
                }
                else{
                    return resp.json();
                }
            })
            .then(resp => {
                    console.log(resp);
                    if(signIn({
                        token: resp.token,
                        expiresIn: calc_expiration_in_min(resp.validUntil),
                        tokenType: "jwt",
                        authState: {
                            username: values["username"],
                            token: `Bearer ${resp.token}`
                        },
                    })){
                        console.log("suceess!", resp.token);
                        message.success(`Hello! ${values["username"]}!`);
                        history.push("/main");
                    }
            })
            .catch((err: any) => console.error(err));
    }

    return (
        <Form
            form={form}
            name="register"
            onFinish={onSubmit}
            onFinishFailed={onSubmitFailed}
            scrollToFirstError
            >
            <Form.Item
                name="username"
                rules={[
                    {
                        required: true,
                        message: 'Please input your username!',
                    },
                ]}
            >
                <Input size="large" prefix={<UserOutlined/>} placeholder="username"/>
            </Form.Item>

            <Form.Item
                name="password"
                rules={[
                    {
                        required: true,
                        message: 'Please input your password!',
                    },
                ]}
                hasFeedback
            >
                <Input.Password size="large" prefix={<LockOutlined/>} placeholder="password" />
            </Form.Item>

            <Form.Item
                name="confirm"
                dependencies={['password']}
                hasFeedback
                rules={[
                    {
                        required: true,
                        message: 'Please confirm your password!',
                    },
                    ({ getFieldValue }) => ({
                        validator(_, value) {
                            if (!value || getFieldValue('password') === value) {
                                return Promise.resolve();
                            }
                            return Promise.reject(new Error('The two passwords that you entered do not match!'));
                        },
                    }),
                ]}
            >
                <Input.Password size="large" prefix={<LockOutlined/>} placeholder="confirm password"/>
            </Form.Item>

            <div className="py-2"/>
            <Form.Item>
                <Button
                    variant="primary" className="btn-block"
                    type="submit"
                    style={{width: '100%'}}
                    size="lg">
                    Create An Account
                </Button>
            </Form.Item>
            <AButton type="primary" href="/signup" ghost>
                Already has an account?
            </AButton>
        </Form>
    )
}

const Register = () => {
    return (
        <IntroContainer>
            <p className="signIn">Sign Up</p>
            <RegisterForm/>
        </IntroContainer>
    );
}

export default Register;
