import {message} from "antd";

export const calc_expiration_in_min = (expiration: string) => {
    const now = new Date();
    const valid = new Date(expiration);
    return Math.abs(now.getTime() - valid.getTime()) / 60000;
}

export const onSubmitFailed = () => {
    message.error("Please make sure that all fields are correct.").then();
}