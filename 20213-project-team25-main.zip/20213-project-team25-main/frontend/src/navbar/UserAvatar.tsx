import {useAuthUser, useSignOut} from "react-auth-kit";
import {Avatar, Button, Popover} from "antd";
import {UserOutlined} from "@ant-design/icons";
import {AuthStateUserObject} from "react-auth-kit/dist/types";

export const UserAvatar = () => {

    const auth = useAuthUser();
    const user: AuthStateUserObject | null = auth();

    const signOut = useSignOut();

    const getGreeting = () => {
        const date = new Date();
        const currentTime = date.getHours();


        if (currentTime >= 0 && currentTime <= 12) {
            return "Good Morning";
        } else if (currentTime > 12 && currentTime <= 18) {
            return "Good Afternoon";
        } else {
            return "Good Evening";
        }
    }
    if (user === null) return <div/>
    return (
        <Popover
            title={`${getGreeting()}, ${user.username}`}
            trigger="click"
            content={
                <div id="groupie-navbar-avatar-popover">
                    <Button
                        type="dashed" onClick={() => signOut()} danger className="groupie-logout-button">
                        Logout
                    </Button>
                </div>
                }
        >
            <Avatar icon={<UserOutlined/>} size="large" className="groupie-user-avatar"/>
        </Popover>
    )
}