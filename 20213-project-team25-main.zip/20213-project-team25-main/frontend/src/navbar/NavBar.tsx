import {Nav, Navbar} from "react-bootstrap"
import {UserAvatar} from "./UserAvatar";
import './NavBar.css'
import icon from '../images/icon.png'

export const NavBar = () => {
    return (
        <Navbar id="groupie-navbar">
            <Navbar.Brand className="navbar-icon-brand ms-2" href="/main">
                <img src={icon} alt="icon" className="icon-img"/>
                GROUPIE
            </Navbar.Brand>
            <Navbar.Toggle />
            <Navbar.Collapse className="justify-content-end">
                <Nav className="ms-auto me-3">
                    <UserAvatar/>
                </Nav>
            </Navbar.Collapse>
        </Navbar>
    )
}