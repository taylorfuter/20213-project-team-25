import {BrowserRouter} from "react-router-dom";
import {Redirect, Route, Switch} from "react-router";
import {Main} from "../pages/Main";
import {ViewProposedInvitations} from "../pages/ViewInvitations/ViewProposedInvitations";
import {TicketMaster} from "../pages/TicketMaster";
import {UserSettings} from "../pages/UserSettings";
import {useIdleTimer} from "react-idle-timer";
import {message} from "antd";
import {useSignOut} from "react-auth-kit";
import {ViewInvitedInvitations} from "../pages/ViewInvitations/ViewInvitedInvitations";

/**
 * only when auth is completed
 */
export const ProtectedRouter = () => {
    const signOut = useSignOut();

    const handleOnIdle = () => {
        message.warn("60s inactive, logging out...");
        signOut();
    }

    useIdleTimer({
        // 60 seconds
        timeout: 60000,
        onIdle: handleOnIdle,
        debounce: 500
    })

    return (
        <BrowserRouter>
            <Switch>
                <Route exact path="/main" component={Main}/>
                <Route exact path="/settings" component={UserSettings}/>
                <Route exact path="/invites/proposed" component={ViewProposedInvitations}/>
                <Route exact path="/invites/invited" component={ViewInvitedInvitations}/>
                <Route exact path="/propose" component={TicketMaster}/>
                <Redirect to="/main"/>
            </Switch>
        </BrowserRouter>
    )
}
