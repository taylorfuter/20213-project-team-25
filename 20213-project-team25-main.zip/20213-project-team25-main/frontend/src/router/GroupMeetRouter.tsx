import {Redirect, Route, Switch} from "react-router";
import Login from "../auth/Login";
import Register from "../auth/Register";
import {BrowserRouter} from "react-router-dom";
import {PrivateRoute} from "react-auth-kit";
import {ProtectedRouter} from "./ProtectedRouter";
import {NavBar} from "../navbar/NavBar";
import React from "react";
import {Layout} from 'antd';

const { Header, Content, Footer } = Layout;


export const GroupMeetRouter = () => {
    return (
        <BrowserRouter>
            <Layout style={{
                backgroundColor: "#252323",
                height: "100vh", overflow: "scroll"}}>
                <Header style={{padding: "0%"}}>
                    <NavBar/>
                </Header>
                <Content>
                    <Switch>
                        <Route exact path="/login" component={Login}/>
                        <Route exact path="/register" component={Register}/>
                        <PrivateRoute exact path="/main" component={ProtectedRouter} loginPath="/login"/>
                        <Redirect to="/main"/>
                    </Switch>
                </Content>
                <Footer style={{
                    textAlign: 'center',
                    height: '4vh',
                    paddingTop: '1vh',
                    position: "fixed",
                    left: 0,
                    bottom: 0,
                    width: '100%',
                    fontWeight: "bold",
                }}>
                    © TEAM25
                </Footer>
            </Layout>
        </BrowserRouter>
    )
}