To run the frontend

Run `npm install` first to install the dependencies

Then `npm start` to start the frontend (after starting the docker)
